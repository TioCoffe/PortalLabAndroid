/* =====================================================================
   PORTAL LAB — TESTES DE FUGA
   ---------------------------------------------------------------------
   Este é o ficheiro principal do jogo.

   O que encontras aqui:
   1. Criação do mundo 3D e da câmara em primeira pessoa.
   2. Movimento, colisões e saltos.
   3. Disparo e ligação dos dois portais.
   4. Cubos, plataformas de pressão, relés e portas.
   5. Menu, pausa, cronómetro e progressão pelas dez câmaras.

   O código usa Three.js através do endereço incluído no index.html.
   Não precisas de instalar nada: basta abrir o index.html com internet.
   ===================================================================== */

(() => {
  'use strict';

  // ------------------------------
  // 1. ELEMENTOS DA INTERFACE
  // ------------------------------
  const host = document.getElementById('scene-host');
  const hud = document.getElementById('hud');
  const startScreen = document.getElementById('start-screen');
  const pauseScreen = document.getElementById('pause-screen');
  const completeScreen = document.getElementById('complete-screen');
  const endingScreen = document.getElementById('ending-screen');
  const loadingNote = document.getElementById('loading-note');
  const hint = document.getElementById('interaction-hint');
  const toast = document.getElementById('toast');
  const voiceSubtitle = document.getElementById('voice-subtitle');
  const voiceIndicator = document.getElementById('voice-indicator');
  const liftStatus = document.getElementById('lift-status');
  const liftStatusText = document.getElementById('lift-status-text');

  const levelNumber = document.getElementById('level-number');
  const levelName = document.getElementById('level-name');
  const objectiveText = document.getElementById('objective-text');
  const progressFill = document.getElementById('progress-fill');
  const progressLabel = document.getElementById('progress-label');
  const timerLabel = document.getElementById('timer');
  const resultTimer = document.getElementById('result-timer');
  const totalTimer = document.getElementById('total-timer');
  const completeTitle = document.getElementById('complete-title');
  const completeDescription = document.getElementById('complete-description');
  const menuExtra = document.getElementById('menu-extra');
  const menuExtraText = document.getElementById('menu-extra-text');
  const chamberScreen = document.getElementById('chamber-screen');
  const chamberGrid = document.getElementById('chamber-grid');
  const saveScreen = document.getElementById('save-screen');
  const saveSlots = document.getElementById('save-slots');
  const autoSaveCard = document.getElementById('autosave-card');
  const saveNotice = document.getElementById('save-notice');
  const storyCard = document.getElementById('story-card');
  const storyTitle = document.getElementById('story-title');
  const storyText = document.getElementById('story-text');
  const gelStatus = document.getElementById('gel-status');
  const editorScreen = document.getElementById('editor-screen');
  const editorCanvas = document.getElementById('editor-map');
  const editorCtx = editorCanvas ? editorCanvas.getContext('2d') : null;
  const editorName = document.getElementById('editor-name');
  const editorAuthor = document.getElementById('editor-author');
  const editorObjective = document.getElementById('editor-objective');
  const editorSelection = document.getElementById('editor-selection');
  const editorMessage = document.getElementById('editor-message');
  const editorSavedSelect = document.getElementById('editor-saved-select');
  const mobileControls = document.getElementById('mobile-controls');
  const mobileJoystick = document.getElementById('mobile-joystick');
  const joystickKnob = document.getElementById('joystick-knob');

  // Se a biblioteca 3D não carregar, damos uma mensagem clara em vez de
  // deixar o ecrã vazio. É necessária ligação à internet para o CDN.
  if (typeof THREE === 'undefined') {
    loadingNote.textContent = 'Não foi possível carregar o motor 3D. Verifica a ligação à internet e atualiza a página.';
    return;
  }

  // ------------------------------
  // 2. MOTOR 3D E CÂMARA
  // ------------------------------
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111e29);
  scene.fog = new THREE.Fog(0x111e29, 23, 48);

  const camera = new THREE.PerspectiveCamera(74, window.innerWidth / window.innerHeight, 0.06, 180);
  camera.position.set(6, 1.65, 1.6);
  camera.rotation.order = 'YXZ';
  scene.add(camera); // Permite desenhar o equipamento em primeira pessoa.

  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  // Geometria estática: atualizamos o mapa de sombras ao carregar cada câmara,
  // evitando recalculá-lo três vezes por fotograma (duas vistas de portal + ecrã).
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true;
  renderer.physicallyCorrectLights = true;
  // Compatibilidade com a versão clássica do Three.js carregada no HTML.
  // Nas versões mais recentes usa-se outputColorSpace; nas antigas, outputEncoding.
  if ('outputColorSpace' in renderer && THREE.SRGBColorSpace) {
    renderer.outputColorSpace = THREE.SRGBColorSpace;
  } else if (THREE.sRGBEncoding !== undefined) {
    renderer.outputEncoding = THREE.sRGBEncoding;
  }
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  host.appendChild(renderer.domElement);
  renderer.domElement.tabIndex = 0;

  // A luz ambiente impede que os cantos fiquem completamente pretos.
  scene.add(new THREE.HemisphereLight(0xe2f5ff, 0x29313a, 1.25));
  scene.add(new THREE.AmbientLight(0xffffff, 0.22));
  const mainLight = new THREE.DirectionalLight(0xffffff, 2.0);
  mainLight.position.set(-7, 16, 9);
  mainLight.castShadow = true;
  mainLight.shadow.mapSize.set(2048, 2048);
  mainLight.shadow.bias = -0.00018;
  mainLight.shadow.normalBias = 0.025;
  mainLight.shadow.camera.left = -18;
  mainLight.shadow.camera.right = 18;
  mainLight.shadow.camera.top = 18;
  mainLight.shadow.camera.bottom = -18;
  scene.add(mainLight);

  const clock = new THREE.Clock();
  const raycaster = new THREE.Raycaster();
  const screenCenter = new THREE.Vector2(0, 0);
  const forwardVector = new THREE.Vector3();
  const tempVector = new THREE.Vector3();

  // ------------------------------
  // 3. ESTADO DO JOGO
  // ------------------------------
  const ROOM = { halfX: 12, halfZ: 13, height: 10, wall: 0.5 };
  // Passagem física entre as duas alas da câmara. É suficientemente larga para
  // caminhar com um cubo nas mãos, sem depender dos portais.
  const WALKWAY = { halfWidth: 3.2, clearance: 3.8, wallHalfDepth: 0.21 };
  // O portal vai quase até ao chão para a cápsula inteira do jogador passar sem ficar presa.
  const PORTAL = { width: 1.86, height: 3.9, centerY: 1.85 };
  const PLAYER = { radius: 0.31, eyeHeight: 1.65, height: 1.84, walkSpeed: 4.9, runSpeed: 7.0, jumpSpeed: 5.7, acceleration: 30, friction: 22, gravity: 17.5 };

  let currentLevel = 0;
  let isPlaying = false;
  let hasStarted = false;
  let pointerWasLocked = false;
  let yaw = Math.PI / 2;      // Começa a olhar para a parede central.
  let pitch = 0;
  let verticalSpeed = 0;
  let onGround = true;
  let portalCooldown = 0;
  let heldCube = null;
  let elapsedLevel = 0;
  let totalElapsed = 0;
  let lastHintUpdate = 0;
  let lastToastTimer = 0;
  let lastPortalMessage = 0;
  let relayActivated = false;
  let doorOpen = false;
  let levelFinished = false;
  let totalRunStart = 0;
  let soundContext = null;
  let voiceEnabled = true;
  let voiceHideTimer = 0;
  let horizontalVelocity = new THREE.Vector3();
  let frameCounter = 0;
  let portalViewTimer = 0;
  let launchPadCooldown = 0;
  let portalDevice = null;
  let unlockedLevel = 0;
  let completedLevels = new Set();
  let saveData = null;
  let currentPlatform = null;
  let gelBounceCooldown = 0;
  let gelFeedbackCooldown = 0;
  let currentGelType = null;
  let storyCardTimer = 0;
  let autoSaveTimer = 0;
  let saveManagerReturnToPause = false;
  let activeLevelData = null;
  let customTestMode = false;
  let currentCustomMap = null;
  let editorMap = null;
  let editorSelectedId = null;
  let editorTool = 'select';
  let editorHistory = [];
  let editorSavedMaps = [];
  let touchDevice = Boolean((window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints || 0) > 0);
  const touchMove = { x: 0, y: 0 };
  const touchActions = { jump: false, run: false };
  const mobileLook = { pointerId: null, x: 0, y: 0 };
  let mobileLookSensitivity = 0.0042;

  let portals = { blue: null, orange: null };
  let portalTargets = [];
  let raycastBlockers = [];
  let interactables = [];
  let cubes = [];
  let plates = [];
  let launchPads = [];
  let hazards = [];
  let gelPatches = [];
  let movingPlatforms = [];
  let toxicPools = [];
  let colliders = [];
  let roomObjects = [];
  let levelObjects = [];
  let doorGroup = null; // Mantido como referência ao grupo da porta do elevador de saída.
  let doorPanel = null; // Não usado para colisão; a saída usa duas portas deslizantes.
  let entryLift = null;
  let exitLift = null;
  let liftSequence = null;
  let exitPosition = new THREE.Vector3(-10.78, 1.57, -7.2);

  const keys = Object.create(null);
  const playerVelocity = new THREE.Vector3();

  // Dez câmaras ligadas como uma campanha com alas, corredores e zonas de manutenção.
  // Os objetos estão afastados para incentivar exploração e deslocação a pé.
  const LEVELS = [
    {
      name: 'The Welcome Gallery',
      objective: 'Encontra o cubo no pequeno armazém, atravessa a galeria central e coloca-o na plataforma da ala oposta.',
      storyTitle: 'CANDIDATE 11',
      storyIntro: 'Welcome, Candidate Eleven. Your personnel file appears to have been misplaced. How unusual. Please retrieve the storage cube and proceed to the exit elevator.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 9.0, z: 6.2 }], plates: [{ x: -8.1, z: -8.2 }],
      relay: false, relayPosition: null, obstacles: [], launchPads: [], hazards: [], gels: [], movingPlatforms: [], toxicPools: [],
      accent: 0x25a9d2,
      description: 'The first test is complete. A personnel record has been recovered. It lists you as Candidate Eleven, although the previous ten entries have been redacted.'
    },
    {
      name: 'Power and Passage',
      objective: 'Leva o cubo até à plataforma da ala norte. Atravessa a galeria e ativa o relé para restaurar a energia.',
      storyTitle: 'THE SHUTDOWN',
      storyIntro: 'This testing wing was closed after a minor interruption in the power network. The evacuation was entirely routine. The abandoned lunch trays were not part of the incident.',
      spawn: { x: 8.9, z: -10.45, yaw: Math.PI },
      cubes: [{ x: 8.8, z: -6.1 }], plates: [{ x: -8.2, z: 8.1 }],
      relay: true, relayPosition: { x: -8.2, z: -8.4 }, obstacles: [], launchPads: [], hazards: [], gels: [], movingPlatforms: [], toxicPools: [],
      accent: 0xd27c42,
      description: 'Power restored. The maintenance terminal contains a warning: GEL TRANSFER SYSTEM — DO NOT RESTART. The warning has been filed under optional reading.'
    },
    {
      name: 'Storage Run',
      objective: 'Transporta os dois cubos desde o armazém até às plataformas. Usa a galeria central para percorrer as duas alas.',
      storyTitle: 'MISSING INVENTORY',
      storyIntro: 'Two storage cubes have been logged as missing for nine years. They are directly in front of you. This is either excellent inventory management or a very poor filing system.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 8.8, z: 6.0 }, { x: 5.0, z: 6.8 }],
      plates: [{ x: -8.1, z: -8.3 }, { x: -8.1, z: 7.8 }],
      relay: false, relayPosition: null, obstacles: [], launchPads: [], hazards: [], gels: [], movingPlatforms: [], toxicPools: [],
      accent: 0x7c8bcf,
      description: 'Both cubes are accounted for. A maintenance recording mentions a project called Mobility Enhancement Gel. The recording ends with a rather loud alarm.'
    },
    {
      name: 'Velocity Application',
      objective: 'Experimenta a tinta laranja de velocidade. Corre sobre a faixa brilhante para ganhar impulso e entrega o cubo na plataforma.',
      storyTitle: 'MOBILITY ENHANCEMENT',
      storyIntro: 'The orange substance is propulsion gel. It increases running speed. It is not a beverage, a cleaning product, or a substitute for proper footwear.',
      spawn: { x: 8.9, z: -10.45, yaw: Math.PI },
      cubes: [{ x: 8.7, z: -6.0 }], plates: [{ x: -8.1, z: 8.0 }],
      relay: false, relayPosition: null, obstacles: [], launchPads: [], hazards: [],
      gels: [{ type: 'speed', x: 0.0, z: 0.0, width: 5.6, depth: 4.8 }, { type: 'speed', x: -4.0, z: 0.0, width: 2.3, depth: 2.1 }],
      movingPlatforms: [], toxicPools: [], accent: 0xe58a35,
      description: 'Propulsion gel is flowing again. A hidden maintenance note says the gel system was never designed to be restarted by a test subject.'
    },
    {
      name: 'Repulsion Research',
      objective: 'A tinta azul de salto faz-te ressaltar. Usa os ressaltos para alcançar o relé elevado e coloca o cubo na plataforma.',
      storyTitle: 'A SECOND KIND OF PAINT',
      storyIntro: 'Repulsion gel has been approved for controlled testing. The blue gel causes a strong rebound. Please avoid bouncing into the ceiling. It is expensive.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 8.6, z: 6.2 }], plates: [{ x: -8.0, z: -8.2 }],
      relay: true, relayPosition: { x: 6.8, z: -7.2 }, obstacles: [], launchPads: [], hazards: [],
      gels: [{ type: 'bounce', x: 2.0, z: 0.0, width: 5.0, depth: 4.8 }, { type: 'bounce', x: -3.0, z: 0.0, width: 2.5, depth: 2.0 }],
      movingPlatforms: [], toxicPools: [], accent: 0x39bddd,
      description: 'Repulsion gel tests passed. Someone has written on the maintenance glass: THEY ARE NOT TESTING THE GEL. THEY ARE TESTING YOU.'
    },
    {
      name: 'Paint Transfer Lab',
      objective: 'Combina tinta de velocidade e de salto. Usa a plataforma móvel para atravessar a zona central e ativa o relé.',
      storyTitle: 'THE MIXING ROOM',
      storyIntro: 'Both gels are now active. The orange one accelerates you; the blue one sends you upward. A note from the previous supervisor says the two substances should never be mixed. Naturally, we have painted the entire floor.',
      spawn: { x: 8.9, z: -10.45, yaw: Math.PI },
      cubes: [{ x: 8.6, z: -6.0 }], plates: [{ x: -8.1, z: 8.0 }],
      relay: true, relayPosition: { x: -8.1, z: -8.1 }, obstacles: [], launchPads: [], hazards: [],
      gels: [
        { type: 'speed', x: 2.8, z: 0.0, width: 4.6, depth: 5.2 },
        { type: 'bounce', x: -2.8, z: 0.0, width: 4.6, depth: 5.2 },
        { type: 'speed', x: 5.2, z: 0.0, width: 1.8, depth: 2.0 }
      ],
      movingPlatforms: [{ x: 0.0, z: -5.5, y: 0.48, width: 3.1, depth: 2.3, axis: 'z', travel: 2.0, speed: 0.72 }],
      toxicPools: [], accent: 0xb57bcf,
      description: 'The paint-transfer system is online. A corrupted archive has been recovered. It contains a voice memo from the day the facility went dark.'
    },
    {
      name: 'Kinetic Freight',
      objective: 'Observa o ritmo das plataformas móveis, salta para a plataforma segura e transporta o cubo até ao botão.',
      storyTitle: 'AUTOMATED TRANSPORT',
      storyIntro: 'The freight platforms are still operating. They were programmed to move personnel and equipment to the central maintenance shaft. No personnel have been detected in this wing for nine years.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 8.4, z: 6.0 }], plates: [{ x: -8.0, z: -8.0 }],
      relay: false, relayPosition: null, obstacles: [], launchPads: [], hazards: [], gels: [],
      movingPlatforms: [
        { x: 2.2, z: 4.0, y: 0.48, width: 3.0, depth: 2.4, axis: 'x', travel: 2.4, speed: 0.62 },
        { x: -3.0, z: -4.2, y: 0.48, width: 3.0, depth: 2.4, axis: 'z', travel: 2.3, speed: 0.78, phase: 1.6 }
      ],
      toxicPools: [], accent: 0x65a9bd,
      description: 'The platforms have stopped at the maintenance station. Their passenger manifest contains one entry: CANDIDATE 10. The name has been crossed out.'
    },
    {
      name: 'Flooded Maintenance',
      objective: 'A água verde é tóxica. Usa a plataforma móvel para atravessar a piscina central sem tocar no líquido e entrega o cubo.',
      storyTitle: 'DO NOT ENTER THE WATER',
      storyIntro: 'The green fluid below is a corrosive maintenance solution. It has been labelled WATER by a technician who is no longer employed here. Do not touch it. Please do not drink it either.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 8.5, z: 6.0 }], plates: [{ x: -8.0, z: -8.0 }],
      relay: false, relayPosition: null, obstacles: [], launchPads: [], hazards: [], gels: [],
      movingPlatforms: [{ x: 2.25, z: 0.0, y: 0.52, width: 2.75, depth: 2.45, axis: 'x', travel: 4.45, speed: 0.46, phase: 0 }],
      toxicPools: [{ x: 0.0, z: 0.0, width: 6.35, depth: 6.35 }], accent: 0x55c58a,
      description: 'The toxic reservoir has been bypassed. The old recording is clearer now: the evacuation order was issued from a control room below this one.'
    },
    {
      name: 'Hazardous Recalibration',
      objective: 'Usa a tinta laranja para ganhar velocidade, evita os líquidos tóxicos e segue as plataformas móveis até ao relé.',
      storyTitle: 'THE EVACUATION RECORD',
      storyIntro: 'Aperture staff did not abandon this facility. They were evacuated. The destination field is blank, and the approval signature belongs to the central intelligence system.',
      spawn: { x: 8.9, z: -10.45, yaw: Math.PI },
      cubes: [{ x: 8.5, z: -6.0 }], plates: [{ x: -8.0, z: 8.0 }],
      relay: true, relayPosition: { x: -8.0, z: -8.0 }, obstacles: [], launchPads: [{ x: 4.4, z: 5.0 }], hazards: [],
      gels: [{ type: 'speed', x: 2.6, z: 0.0, width: 4.2, depth: 5.5 }, { type: 'bounce', x: -3.0, z: 0.0, width: 3.7, depth: 4.0 }],
      movingPlatforms: [{ x: -1.9, z: 0.0, y: 0.52, width: 2.8, depth: 2.4, axis: 'z', travel: 2.4, speed: 0.68 }],
      toxicPools: [{ x: 0.0, z: -7.4, width: 4.0, depth: 3.0 }], accent: 0xd1794d,
      description: 'The relay has opened a maintenance channel. A message is being transmitted from the central control room. It knows your name.'
    },
    {
      name: 'The Central Intelligence',
      objective: 'Completa o último circuito: transporta o cubo, usa as tintas, atravessa as plataformas móveis e alcança o elevador final.',
      storyTitle: 'CANDIDATE ELEVEN',
      storyIntro: 'Candidate Eleven, the earlier tests were not designed to measure your problem-solving ability. They were designed to confirm that someone could still reach this control room. Congratulations. You are now considerably less useful to me alive than curious.',
      spawn: { x: 8.9, z: 10.45, yaw: 0 },
      cubes: [{ x: 8.5, z: 6.0 }], plates: [{ x: -8.0, z: -8.0 }],
      relay: true, relayPosition: { x: 7.5, z: -7.5 }, obstacles: [{ x: 7.0, z: -1.8, w: 1.35, d: 1.6, h: 0.72 }],
      launchPads: [], hazards: [],
      gels: [{ type: 'speed', x: 2.4, z: 0.0, width: 4.6, depth: 5.2 }, { type: 'bounce', x: -2.9, z: 0.0, width: 4.4, depth: 5.0 }],
      movingPlatforms: [{ x: 0.0, z: 0.0, y: 0.54, width: 2.9, depth: 2.5, axis: 'x', travel: 3.6, speed: 0.54 }],
      toxicPools: [{ x: 0.0, z: 7.2, width: 4.2, depth: 3.0 }], accent: 0x3eb7da,
      description: 'You reached the central intelligence. The final door is open, but the facility is still running. This was never a routine test. It was a recruitment process.'
    }
  ];

  // ------------------------------
  // 4. FUNÇÕES DE APOIO
  // ------------------------------
  function makeMaterial(color, roughness = 0.72, metalness = 0.05, extra = {}) {
    return new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });
  }

  // Texturas procedurais desenhadas em Canvas: não precisam de imagens externas.
  // Cada tipo tem juntas, riscos e pequenos detalhes para evitar paredes lisas.
  const textureCache = Object.create(null);
  function makeSurfaceTexture(kind, repeatX = 1, repeatY = 1) {
    const key = `${kind}:${repeatX}:${repeatY}`;
    if (textureCache[key]) return textureCache[key];

    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    const palettes = {
      // Painéis claros, quase brancos, com juntas finas como os módulos de teste.
      wall: ['#e6e8e5', '#f0f1ee', '#d9ddda'],
      // Ladrilhos de borracha e metal escuro para zonas de circulação.
      floor: ['#343a3d', '#41484b', '#2d3336'],
      ceiling: ['#bfc7c7', '#d9dedd', '#aeb8b9'],
      // Aço escovado usado em elevadores, condutas e estruturas.
      metal: ['#68757a', '#879296', '#4d5b60'],
      test: ['#eef0ed', '#f8f8f5', '#dfe3df']
    };
    const colors = palettes[kind] || palettes.wall;
    const background = ctx.createLinearGradient(0, 0, 1024, 1024);
    background.addColorStop(0, colors[1]);
    background.addColorStop(0.55, colors[0]);
    background.addColorStop(1, colors[2]);
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, 1024, 1024);

    if (kind === 'wall' || kind === 'test') {
      // Grandes painéis modulares com juntas muito discretas, não um padrão xadrez.
      const panelW = kind === 'wall' ? 256 : 512;
      const panelH = kind === 'wall' ? 256 : 384;
      for (let y = 0; y < 1024; y += panelH) {
        for (let x = 0; x < 1024; x += panelW) {
          const shade = ((x / panelW + y / panelH) % 2 === 0) ? colors[1] : colors[0];
          const gradient = ctx.createLinearGradient(x, y, x + panelW, y + panelH);
          gradient.addColorStop(0, shade);
          gradient.addColorStop(1, colors[2]);
          ctx.fillStyle = gradient;
          ctx.fillRect(x + 3, y + 3, panelW - 6, panelH - 6);
          ctx.strokeStyle = 'rgba(34,47,50,.17)';
          ctx.lineWidth = 2;
          ctx.strokeRect(x + 2, y + 2, panelW - 4, panelH - 4);
          ctx.strokeStyle = 'rgba(255,255,255,.52)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(x + 7, y + 7);
          ctx.lineTo(x + panelW - 8, y + 7);
          ctx.stroke();
          // Parafusos pequenos e quase embutidos nos cantos.
          for (const [sx, sy] of [[x+13,y+13],[x+panelW-13,y+13],[x+13,y+panelH-13],[x+panelW-13,y+panelH-13]]) {
            ctx.fillStyle = 'rgba(45,57,59,.28)';
            ctx.beginPath(); ctx.arc(sx, sy, 2.5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.62)';
            ctx.fillRect(sx - 1, sy - 1, 1.4, 1.4);
          }
        }
      }
      // Marcas subtis de uso junto às juntas e na parte inferior dos painéis.
      const grime = ctx.createLinearGradient(0, 800, 0, 1024);
      grime.addColorStop(0, 'rgba(65,73,72,0)');
      grime.addColorStop(1, 'rgba(65,73,72,.10)');
      ctx.fillStyle = grime; ctx.fillRect(0, 800, 1024, 224);
    } else if (kind === 'floor') {
      const tile = 128;
      for (let y = 0; y < 1024; y += tile) {
        for (let x = 0; x < 1024; x += tile) {
          const g = ctx.createLinearGradient(x, y, x + tile, y + tile);
          g.addColorStop(0, colors[1]); g.addColorStop(1, colors[2]);
          ctx.fillStyle = g;
          ctx.fillRect(x + 3, y + 3, tile - 6, tile - 6);
          ctx.strokeStyle = 'rgba(10,17,20,.48)'; ctx.lineWidth = 5;
          ctx.strokeRect(x + 2, y + 2, tile - 4, tile - 4);
          ctx.strokeStyle = 'rgba(255,255,255,.07)'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(x + 8, y + 8); ctx.lineTo(x + tile - 8, y + 8); ctx.stroke();
        }
      }
    } else if (kind === 'ceiling') {
      // Placas de teto maiores, com linhas de encaixe e grelhas de ventilação.
      for (let y = 0; y < 1024; y += 256) {
        for (let x = 0; x < 1024; x += 256) {
          ctx.strokeStyle = 'rgba(44,56,59,.20)'; ctx.lineWidth = 3;
          ctx.strokeRect(x + 4, y + 4, 248, 248);
          ctx.fillStyle = 'rgba(60,75,80,.08)'; ctx.fillRect(x + 18, y + 18, 220, 4);
          for (let n = 0; n < 12; n++) {
            ctx.fillStyle = 'rgba(45,57,61,.16)';
            ctx.fillRect(x + 30 + n * 16, y + 205, 8, 22);
          }
        }
      }
    } else if (kind === 'metal') {
      // Metal escovado: linhas horizontais, ligeiras diferenças de brilho e riscos.
      for (let y = 0; y < 1024; y += 64) {
        ctx.fillStyle = y % 128 === 0 ? 'rgba(255,255,255,.055)' : 'rgba(0,0,0,.045)';
        ctx.fillRect(0, y, 1024, 3);
      }
      ctx.strokeStyle = 'rgba(255,255,255,.07)'; ctx.lineWidth = 1;
      for (let y = 6; y < 1024; y += 12) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(1024, y); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(0,0,0,.11)';
      for (let x = 30; x < 1024; x += 256) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 1024); ctx.stroke();
      }
    }

    // Sujidade, micro-riscos e pequenas variações para não parecer plástico uniforme.
    let seed = kind.length * 7919 + 17;
    const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    for (let i = 0; i < 6200; i++) {
      const x = rand() * 1024, y = rand() * 1024;
      const alpha = 0.018 + rand() * 0.035;
      ctx.fillStyle = rand() > .5 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
      ctx.fillRect(x, y, 1 + rand() * 2.6, 1 + rand() * 2.0);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(repeatX, repeatY);
    texture.anisotropy = Math.min(12, renderer.capabilities.getMaxAnisotropy());
    if (THREE.sRGBEncoding !== undefined) texture.encoding = THREE.sRGBEncoding;
    textureCache[key] = texture;
    return texture;
  }

  function texturedMaterial(color, kind, repeatX, repeatY, roughness = 0.8, metalness = 0.03) {
    const map = makeSurfaceTexture(kind, repeatX, repeatY);
    return makeMaterial(color, roughness, metalness, { map, bumpMap: map, bumpScale: kind === 'floor' ? 0.035 : 0.018 });
  }

  // Decal de sinalização: texto técnico desenhado localmente, sem imagens externas.
  function makeApertureDecalTexture(title, subtitle) {
    const canvas = document.createElement('canvas');
    canvas.width = 768; canvas.height = 256;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#172832'; ctx.fillRect(0, 0, 768, 256);
    ctx.fillStyle = '#20b9e8'; ctx.fillRect(0, 0, 13, 256);
    ctx.strokeStyle = 'rgba(178,220,234,.32)'; ctx.lineWidth = 3; ctx.strokeRect(18, 18, 732, 220);
    ctx.fillStyle = '#e8f0f2'; ctx.font = 'bold 57px Arial'; ctx.fillText('APERTURE', 43, 103);
    ctx.fillStyle = '#36c2ed'; ctx.font = 'bold 23px Arial'; ctx.fillText(title.toUpperCase(), 45, 153);
    ctx.fillStyle = '#9fb4bd'; ctx.font = '17px Arial'; ctx.fillText(subtitle.toUpperCase(), 45, 193);
    ctx.fillStyle = '#36c2ed';
    for (let i = 0; i < 5; i++) ctx.fillRect(620 + i * 19, 185, 9, 18);
    const texture = new THREE.CanvasTexture(canvas);
    if (THREE.sRGBEncoding !== undefined) texture.encoding = THREE.sRGBEncoding;
    texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    return texture;
  }

  // Placas de parede da instalação: fundo metálico, aro e impressão de alta legibilidade.
  function addWorldSign(title, subtitle, position, normal, width = 3.0, height = 0.95) {
    const group = new THREE.Group();
    group.position.copy(position);
    group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal.clone().normalize());
    const backing = new THREE.Mesh(new THREE.BoxGeometry(width + 0.16, height + 0.16, 0.12), makeMaterial(0x26343a, 0.52, 0.5));
    backing.position.z = -0.015;
    group.add(backing);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(width, height), new THREE.MeshBasicMaterial({
      map: makeApertureDecalTexture(title, subtitle), toneMapped: false, side: THREE.DoubleSide
    }));
    face.position.z = 0.052;
    group.add(face);
    const topLine = new THREE.Mesh(new THREE.BoxGeometry(width + 0.08, 0.035, 0.035), makeMaterial(0x26b9e8, 0.35, 0.35, { emissive: 0x147a99, emissiveIntensity: 0.5 }));
    topLine.position.set(0, height / 2 + 0.075, 0.02);
    group.add(topLine);
    scene.add(group);
    levelObjects.push(group);
    return group;
  }

  // Monta uma cabine de elevador Aperture. O eixo local +Z aponta para a câmara;
  // a cabine fica atrás da porta, no sentido -Z, qualquer que seja a orientação.
  function createLiftCabin(position, normal, label, options = {}) {
    const width = options.width || 3.55;
    const depth = options.depth || 3.15;
    const height = options.height || 3.55;
    const group = new THREE.Group();
    group.position.copy(position);
    group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal.clone().normalize());

    const shellMat = texturedMaterial(0xe7e9e6, 'wall', 1.4, 1.2, 0.78, 0.08);
    const steelMat = texturedMaterial(0xaeb9ba, 'metal', 1.15, 1.2, 0.42, 0.58);
    const darkMat = makeMaterial(0x202a2e, 0.48, 0.62);
    const trimMat = makeMaterial(0x3a4a50, 0.42, 0.7);
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xd9f8ff });
    const blueMat = new THREE.MeshBasicMaterial({ color: 0x31bce9 });
    const orangeMat = new THREE.MeshBasicMaterial({ color: 0xf39a55 });

    // Pavimento em chapa e teto interior da cabine.
    const floor = new THREE.Mesh(new THREE.BoxGeometry(width, 0.07, depth), steelMat);
    floor.position.set(0, 0.02, -depth / 2);
    floor.receiveShadow = true; group.add(floor);
    const ceiling = new THREE.Mesh(new THREE.BoxGeometry(width, 0.13, depth), shellMat);
    ceiling.position.set(0, height - 0.06, -depth / 2); group.add(ceiling);
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(width, height, 0.16), shellMat);
    backWall.position.set(0, height / 2, -depth + 0.04); backWall.receiveShadow = true; group.add(backWall);

    // Painéis laterais e perfis verticais da estrutura.
    for (const side of [-1, 1]) {
      const sideWall = new THREE.Mesh(new THREE.BoxGeometry(0.13, height, depth), shellMat);
      sideWall.position.set(side * (width / 2 - 0.065), height / 2, -depth / 2);
      sideWall.receiveShadow = true; group.add(sideWall);
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.055, height - 0.36, 0.09), trimMat);
      rail.position.set(side * (width / 2 - 0.15), height / 2, -depth / 2);
      group.add(rail);
      for (let y = 0.35; y < height - 0.2; y += 0.52) {
        const bolt = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 6), darkMat);
        bolt.position.set(side * (width / 2 - 0.11), y, -depth / 2);
        group.add(bolt);
      }
    }

    // Moldura da porta e duas folhas que deslizam para os lados.
    const postGeo = new THREE.BoxGeometry(0.16, height, 0.22);
    for (const side of [-1, 1]) {
      const post = new THREE.Mesh(postGeo, trimMat);
      post.position.set(side * (width / 2 - 0.06), height / 2, 0.04);
      post.castShadow = true; group.add(post);
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(width, 0.18, 0.24), trimMat);
    lintel.position.set(0, height - 0.09, 0.04); group.add(lintel);

    const doors = [];
    const doorMaterial = new THREE.MeshStandardMaterial({ map: makeSurfaceTexture('metal', 1.0, 1.0), color: 0xdce2e1, roughness: 0.48, metalness: 0.46 });
    const doorWidth = width * 0.405;
    for (const side of [-1, 1]) {
      const door = new THREE.Group();
      const slab = new THREE.Mesh(new THREE.BoxGeometry(doorWidth, height - 0.48, 0.13), doorMaterial);
      slab.position.y = (height - 0.48) / 2 + 0.08;
      slab.castShadow = true; door.add(slab);
      const inset = new THREE.Mesh(new THREE.BoxGeometry(doorWidth - 0.16, height - 0.72, 0.018), shellMat);
      inset.position.set(0, slab.position.y, 0.075); door.add(inset);
      const seam = new THREE.Mesh(new THREE.BoxGeometry(0.025, height - 0.8, 0.022), darkMat);
      seam.position.set(side * (doorWidth / 2 - 0.08), slab.position.y, 0.09); door.add(seam);
      door.position.set(side * (doorWidth / 2), 0, 0.11);
      group.add(door); doors.push({ mesh: door, side });
    }

    // Placa luminosa acima da porta com nome do elevador/câmara.
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.9, 0.72), new THREE.MeshBasicMaterial({
      map: makeApertureDecalTexture(label, 'Elevator Transit · Authorized Testing Personnel'),
      toneMapped: false, side: THREE.DoubleSide
    }));
    sign.position.set(0, height + 0.5, 0.13); group.add(sign);
    const signFrame = new THREE.Mesh(new THREE.BoxGeometry(3.04, 0.82, 0.09), darkMat);
    signFrame.position.set(0, height + 0.5, 0.07); group.add(signFrame);
    sign.position.z = 0.125;

    // Indicador de estado e difusor de luz interior.
    const indicator = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.13, 0.04), blueMat);
    indicator.position.set(width / 2 - 0.33, height - 0.42, 0.18); group.add(indicator);
    const roofLight = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.035, 0.36), lightMat);
    roofLight.position.set(0, height - 0.17, -depth / 2); group.add(roofLight);
    const lamp = new THREE.PointLight(0xe4f6ff, 0.8, 7, 2);
    lamp.position.set(0, height - 0.35, -depth / 2); group.add(lamp);

    // Friso de segurança na soleira com faixas alternadas.
    const stripeBlack = darkMat;
    const stripeYellow = makeMaterial(0xe4b04a, 0.72, 0.12);
    for (let i = 0; i < 12; i++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(width / 12 + 0.01, 0.025, 0.13), i % 2 ? stripeYellow : stripeBlack);
      stripe.position.set(-width / 2 + width * (i + 0.5) / 12, 0.07, 0.19);
      group.add(stripe);
    }

    scene.add(group);
    levelObjects.push(group);
    return { group, doors, indicator, indicatorBlue: blueMat, lamp, openAmount: 0, targetOpen: 0, width, depth, height, label };
  }

  function updateLiftDoors(lift, dt) {
    if (!lift) return;
    lift.openAmount = THREE.MathUtils.lerp(lift.openAmount, lift.targetOpen, Math.min(1, dt * 4.8));
    for (const door of lift.doors) {
      // Em fechado as duas folhas encontram-se no centro; abertas recolhem para os lados.
      door.mesh.position.x = door.side * (lift.width * 0.405 / 2 + lift.openAmount * 0.78);
    }
    if (lift.indicator) {
      const active = lift.targetOpen > 0.5;
      lift.indicator.material.color.setHex(active ? 0x44d8a0 : 0x31bce9);
    }
  }

  function setLiftStatus(message, visible = true) {
    if (!liftStatus || !liftStatusText) return;
    liftStatusText.textContent = message;
    liftStatus.classList.toggle('hidden', !visible);
  }

  // A porta principal do elevador de entrada fica na parede de trás da câmara.
  // O jogador começa dentro da cabine e só recupera o controlo quando as portas abrem.
  function buildEntryLift(level) {
    const sign = Math.sign(level.spawn.z) || 1;
    const frontZ = sign * 8.88;
    const normal = new THREE.Vector3(0, 0, -sign);
    entryLift = createLiftCabin(new THREE.Vector3(level.spawn.x, 0, frontZ), normal,
      `CHAMBER ${String(currentLevel + 1).padStart(2, '0')} · ENTRY`, { width: 3.55, depth: 3.35, height: 3.55 });
    entryLift.targetOpen = 0;
    // Colisão simples nas paredes laterais/traseiras da cabine: o vão da porta fica livre.
    const centerZ = sign * (Math.abs(frontZ) + entryLift.depth / 2);
    addCollider(level.spawn.x - 1.78, centerZ, 0.16, entryLift.depth, 0, entryLift.height);
    addCollider(level.spawn.x + 1.78, centerZ, 0.16, entryLift.depth, 0, entryLift.height);
    addCollider(level.spawn.x, sign * (Math.abs(frontZ) + entryLift.depth), 3.55, 0.16, 0, entryLift.height);
  }

  function addChamberSigns(level) {
    // Sinalética técnica fixa, com setas de circulação e avisos de segurança.
    addWorldSign(`TEST CHAMBER ${String(currentLevel + 1).padStart(2, '0')}`, 'APERTURE SCIENCE · TESTING AREA',
      new THREE.Vector3(11.43, 6.85, -1.2), new THREE.Vector3(-1, 0, 0), 3.2, 0.95);
    addWorldSign('EXIT / ELEVATOR', 'FOLLOW THE BLUE FLOOR GUIDES',
      new THREE.Vector3(-11.43, 6.75, 1.5), new THREE.Vector3(1, 0, 0), 2.85, 0.88);
    if ((level.hazards || []).length || (level.launchPads || []).length || (level.toxicPools || []).length) {
      addWorldSign((level.toxicPools || []).length ? 'TOXIC FLUID' : 'CAUTION', (level.toxicPools || []).length ? 'DO NOT ENTER · CORROSIVE' : 'KINETIC EQUIPMENT · KEEP CLEAR',
        new THREE.Vector3(11.43, 5.25, -5.0), new THREE.Vector3(-1, 0, 0), 2.6, 0.78);
    }
  }

  // Pequeno dispositivo de portais visível na parte inferior do ecrã.
  function createPortalDevice() {
    portalDevice = new THREE.Group();
    const shell = makeMaterial(0xe7eff1, 0.3, 0.42);
    const shellShade = makeMaterial(0x9eafb5, 0.32, 0.55);
    const dark = makeMaterial(0x152630, 0.34, 0.72);
    const steel = makeMaterial(0x647b85, 0.24, 0.82);
    const blueGlow = new THREE.MeshBasicMaterial({ color: 0x42caff });
    const orangeGlow = new THREE.MeshBasicMaterial({ color: 0xffa05b });

    // Corpo cerâmico curvo e núcleo cilíndrico, em vez de uma simples caixa.
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.22, 32, 24), shell);
    body.scale.set(1.0, 0.72, 1.48);
    body.position.set(0, 0.02, -0.13);
    portalDevice.add(body);
    const bodyBand = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.025, 10, 32), shellShade);
    bodyBand.scale.set(1, 0.85, 1);
    bodyBand.rotation.x = Math.PI / 2;
    bodyBand.position.set(0, 0.02, -0.34);
    portalDevice.add(bodyBand);

    const core = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.13, 0.48, 28), dark);
    core.rotation.x = Math.PI / 2;
    core.position.set(0, 0.025, -0.46);
    portalDevice.add(core);
    const barrelSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.125, 0.105, 0.20, 28), steel);
    barrelSleeve.rotation.x = Math.PI / 2;
    barrelSleeve.position.set(0, 0.025, -0.69);
    portalDevice.add(barrelSleeve);
    const muzzle = new THREE.Mesh(new THREE.TorusGeometry(0.112, 0.028, 12, 36), blueGlow);
    muzzle.position.set(0, 0.025, -0.80);
    portalDevice.add(muzzle);
    const muzzleGlass = new THREE.Mesh(new THREE.CircleGeometry(0.083, 32), dark);
    muzzleGlass.position.set(0, 0.025, -0.795);
    portalDevice.add(muzzleGlass);
    const innerLens = new THREE.Mesh(new THREE.CircleGeometry(0.047, 24), blueGlow);
    innerLens.position.set(0, 0.025, -0.80);
    portalDevice.add(innerLens);

    // Duas hastes dianteiras em V formam a silhueta reconhecível da arma de portais.
    function addProng(a, b, radius, material) {
      const start = new THREE.Vector3(...a);
      const end = new THREE.Vector3(...b);
      const direction = end.clone().sub(start);
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.72, radius, direction.length(), 12), material);
      rod.position.copy(start).add(end).multiplyScalar(0.5);
      rod.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
      portalDevice.add(rod);
      const tip = new THREE.Mesh(new THREE.SphereGeometry(radius * 1.55, 12, 10), material);
      tip.position.copy(end);
      portalDevice.add(tip);
    }
    addProng([-0.11, 0.08, -0.31], [-0.19, 0.12, -0.82], 0.025, shellShade);
    addProng([0.11, 0.08, -0.31], [0.19, 0.12, -0.82], 0.025, shellShade);
    addProng([-0.10, -0.02, -0.30], [-0.14, -0.04, -0.75], 0.014, steel);
    addProng([0.10, -0.02, -0.30], [0.14, -0.04, -0.75], 0.014, steel);

    // Punho com inserção de borracha, gatilho e indicadores de cor.
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.145, 0.32, 0.18), dark);
    handle.position.set(0, -0.205, 0.015);
    handle.rotation.x = -0.16;
    handle.rotation.z = 0.04;
    portalDevice.add(handle);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.17, 0.19), steel);
    grip.position.set(0, -0.27, -0.005);
    portalDevice.add(grip);
    const trigger = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.012, 8, 18), shellShade);
    trigger.position.set(0, -0.09, -0.12);
    portalDevice.add(trigger);
    const sideBlue = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 12), blueGlow);
    sideBlue.position.set(-0.16, 0.055, -0.18); portalDevice.add(sideBlue);
    const sideOrange = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 12), orangeGlow);
    sideOrange.position.set(0.16, 0.055, -0.18); portalDevice.add(sideOrange);

    portalDevice.position.set(0.38, -0.34, -0.66);
    portalDevice.rotation.set(-0.12, -0.08, -0.08);
    portalDevice.scale.setScalar(0.80);
    portalDevice.traverse(child => { if (child.isMesh) { child.castShadow = false; child.receiveShadow = false; } });
    camera.add(portalDevice);
  }

  function updatePortalDevice(time) {
    if (!portalDevice) return;
    portalDevice.position.y = -0.34 + Math.sin(time * 2.1) * 0.008;
    portalDevice.rotation.z = -0.08 + Math.sin(time * 1.7) * 0.008;
  }

  function addMesh(geometry, material, position, parent = scene) {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.copy(position);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    levelObjects.push(mesh);
    return mesh;
  }

  function addBox(width, height, depth, material, x, y, z, parent = scene) {
    return addMesh(new THREE.BoxGeometry(width, height, depth), material, new THREE.Vector3(x, y, z), parent);
  }

  function addCollider(x, z, width, depth, bottom = 0, height = 5) {
    colliders.push({ minX: x - width / 2, maxX: x + width / 2, minZ: z - depth / 2, maxZ: z + depth / 2, minY: bottom, maxY: bottom + height });
  }

  function showToast(message, duration = 2.0) {
    toast.textContent = message;
    toast.classList.add('show');
    lastToastTimer = duration;
  }

  // Efeitos sonoros simples, criados no próprio navegador (sem ficheiros de áudio).
  function playTone(frequency = 440, duration = 0.12, wave = 'sine', volume = 0.045) {
    try {
      if (!soundContext) soundContext = new (window.AudioContext || window.webkitAudioContext)();
      if (soundContext.state === 'suspended') soundContext.resume();
      const oscillator = soundContext.createOscillator();
      const gain = soundContext.createGain();
      oscillator.type = wave;
      oscillator.frequency.setValueAtTime(frequency, soundContext.currentTime);
      gain.gain.setValueAtTime(volume, soundContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, soundContext.currentTime + duration);
      oscillator.connect(gain);
      gain.connect(soundContext.destination);
      oscillator.start();
      oscillator.stop(soundContext.currentTime + duration);
    } catch (error) {
      // O jogo continua normalmente mesmo que o navegador não permita áudio.
    }
  }

  // Falas completamente originais de uma supervisora artificial sarcástica.
  // A voz é sintetizada pelo navegador; não é uma gravação nem uma imitação do elenco original.
  const AI_LINES = {
    welcome: 'Welcome to Aperture Laboratories. Please keep your hands inside the testing area. This is not a suggestion.',
    next: 'Another chamber. Another opportunity to demonstrate that survival instincts and scientific curiosity are not mutually exclusive.',
    liftDepart: 'The elevator is now moving. Please remain inside the marked area. If you feel the urge to press every button, that is not a recognized testing objective.',
    cube: 'You picked up the cube. Excellent. It is already contributing more than most previous test subjects.',
    portal: 'You have successfully used a portal. Try to remain calm. The laws of physics are doing their best.',
    plate: 'The pressure plate is active. A small victory for science, and a surprisingly large one for you.',
    relay: 'Power restored. The lights are on, the door is moving, and my expectations remain carefully underground.',
    launch: 'That was a kinetic propulsion device. Please do not attempt to explain the resulting trajectory to the physics department.',
    hazard: 'You have contacted a non-lethal test hazard. The word non-lethal is doing a remarkable amount of work in that sentence.',
    door: 'The exit is open. Please proceed. I would clap, but I have no hands and an extremely strict budget.',
    complete: 'Test complete. You may feel proud for approximately four seconds. I have scheduled no additional praise.',
    voiceOn: 'Voice commentary enabled. I will now provide the encouragement you did not request.',
    voiceOff: 'Voice commentary disabled. Finally, some silence. I shall try not to enjoy it.',
    speedGel: 'Propulsion gel detected. Your running speed has increased. Try not to confuse velocity with competence.',
    bounceGel: 'Repulsion gel detected. You are now a projectile with administrative responsibilities.',
    toxic: 'That liquid is toxic. The label was not decorative. Please return to the last safe surface.'
  };

  function speakAI(line) {
    if (!line || !voiceSubtitle) return;
    voiceSubtitle.textContent = line;
    voiceSubtitle.classList.add('visible');
    voiceHideTimer = 7.0;
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(line);
      utterance.lang = 'en-GB';
      utterance.rate = 0.88;
      utterance.pitch = 0.58;
      utterance.volume = 0.88;
      const voices = window.speechSynthesis.getVoices();
      const selectedVoice = voices.find(voice => /^en-GB/i.test(voice.lang) && /(female|serena|karen|hazel|susan|google uk)/i.test(voice.name))
        || voices.find(voice => /^en-GB/i.test(voice.lang))
        || voices.find(voice => /^en-US/i.test(voice.lang))
        || voices.find(voice => /^en/i.test(voice.lang));
      if (selectedVoice) utterance.voice = selectedVoice;
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      // As legendas continuam visíveis mesmo que a síntese de voz falhe.
    }
  }

  function sayAI(key) {
    speakAI(AI_LINES[key]);
  }

  function showChapterStory(level) {
    if (!level) return;
    storyTitle.textContent = level.storyTitle || `CHAMBER ${String(currentLevel + 1).padStart(2, '0')}`;
    storyText.textContent = level.storyIntro || '';
    storyCard.classList.remove('hidden');
    storyCardTimer = 10;
    speakAI(level.storyIntro || AI_LINES.welcome);
  }

  function formatTime(seconds) {
    const safe = Math.max(0, Math.floor(seconds));
    const minutes = String(Math.floor(safe / 60)).padStart(2, '0');
    const secs = String(safe % 60).padStart(2, '0');
    return `${minutes}:${secs}`;
  }


  // ------------------------------
  // 3A. SISTEMA DE SAVES LOCAIS
  // ------------------------------
  const SAVE_STORAGE_KEY = 'portalLabCampaignSaves_v6';
  const SAVE_SLOT_COUNT = 3;

  function readSaveData() {
    const blank = { version: 1, unlockedLevel: 0, completedLevels: [], campaignComplete: false, auto: null, slots: Array(SAVE_SLOT_COUNT).fill(null) };
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version === 1 && Array.isArray(parsed.slots)) {
          return {
            version: 1,
            unlockedLevel: Math.max(0, Math.min(LEVELS.length - 1, Number(parsed.unlockedLevel) || 0)),
            completedLevels: Array.isArray(parsed.completedLevels) ? parsed.completedLevels.filter(n => Number.isInteger(n) && n >= 0 && n < LEVELS.length) : [],
            campaignComplete: parsed.campaignComplete === true,
            auto: parsed.auto && typeof parsed.auto === 'object' ? parsed.auto : null,
            slots: Array.from({ length: SAVE_SLOT_COUNT }, (_, i) => parsed.slots[i] || null)
          };
        }
      }
      // Importa a progressão simples das versões anteriores sem apagar os dados antigos.
      const legacyProgress = Number(localStorage.getItem('portalLabBestProgress') || 0);
      blank.unlockedLevel = Math.max(0, Math.min(LEVELS.length - 1, legacyProgress));
      return blank;
    } catch (error) {
      return blank;
    }
  }

  function writeSaveData() {
    if (!saveData) return false;
    saveData.unlockedLevel = Math.max(unlockedLevel, 0);
    saveData.completedLevels = [...completedLevels].sort((a, b) => a - b);
    try {
      localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(saveData));
      return true;
    } catch (error) {
      return false;
    }
  }

  function captureSnapshot() {
    return {
      level: currentLevel,
      unlockedLevel,
      completedLevels: [...completedLevels],
      player: hasStarted ? { x: camera.position.x, y: camera.position.y, z: camera.position.z, yaw, pitch } : null,
      verticalSpeed, onGround,
      horizontalVelocity: { x: horizontalVelocity.x, z: horizontalVelocity.z },
      heldCubeIndex: heldCube ? heldCube.index : -1,
      gelBounceCooldown,
      elapsedLevel,
      totalElapsed,
      voiceEnabled,
      relayActive: !!(relay && relay.active),
      doorOpen,
      cubes: cubes.map(cube => ({ x: cube.group.position.x, y: cube.group.position.y, z: cube.group.position.z })),
      platformPhases: movingPlatforms.map(platform => platform.phase),
      currentPlatformIndex: currentPlatform ? movingPlatforms.indexOf(currentPlatform) : -1,
      portals: {
        blue: portals.blue ? { position: portals.blue.group.position.toArray(), normal: portals.blue.normal.toArray() } : null,
        orange: portals.orange ? { position: portals.orange.group.position.toArray(), normal: portals.orange.normal.toArray() } : null
      },
      savedAt: Date.now()
    };
  }

  function saveAutoCheckpoint(nextLevel = null) {
    if (!saveData || customTestMode) return false;
    const snapshot = captureSnapshot();
    if (Number.isInteger(nextLevel)) {
      snapshot.level = Math.max(0, Math.min(LEVELS.length - 1, nextLevel));
      snapshot.player = null;
      snapshot.elapsedLevel = 0;
      snapshot.relayActive = false;
      snapshot.doorOpen = false;
      snapshot.cubes = [];
      snapshot.portals = null;
      snapshot.platformPhases = [];
      snapshot.currentPlatformIndex = -1;
      snapshot.heldCubeIndex = -1;
    }
    saveData.auto = snapshot;
    return writeSaveData();
  }

  function loadSnapshot(snapshot) {
    if (!snapshot || !Number.isInteger(Number(snapshot.level))) return false;
    const levelIndex = Math.max(0, Math.min(LEVELS.length - 1, Number(snapshot.level)));
    unlockedLevel = Math.max(unlockedLevel, Number(snapshot.unlockedLevel) || 0);
    if (Array.isArray(snapshot.completedLevels)) {
      snapshot.completedLevels.forEach(index => { if (Number.isInteger(index) && index >= 0 && index < LEVELS.length) completedLevels.add(index); });
    }
    buildLevel(levelIndex);
    if (snapshot.player && Number.isFinite(snapshot.player.x) && Number.isFinite(snapshot.player.z)) {
      camera.position.set(snapshot.player.x, Math.max(PLAYER.eyeHeight, Number(snapshot.player.y) || PLAYER.eyeHeight), snapshot.player.z);
      yaw = Number(snapshot.player.yaw) || 0;
      pitch = THREE.MathUtils.clamp(Number(snapshot.player.pitch) || 0, -1.42, 1.42);
      camera.rotation.set(pitch, yaw, 0, 'YXZ');
    }
    verticalSpeed = Number.isFinite(snapshot.verticalSpeed) ? snapshot.verticalSpeed : 0;
    onGround = snapshot.onGround !== false;
    if (snapshot.horizontalVelocity && Number.isFinite(snapshot.horizontalVelocity.x) && Number.isFinite(snapshot.horizontalVelocity.z)) {
      horizontalVelocity.set(snapshot.horizontalVelocity.x, 0, snapshot.horizontalVelocity.z);
      playerVelocity.x = horizontalVelocity.x;
      playerVelocity.z = horizontalVelocity.z;
    }
    gelBounceCooldown = Math.max(0, Number(snapshot.gelBounceCooldown) || 0);
    if (Array.isArray(snapshot.platformPhases)) {
      snapshot.platformPhases.forEach((phase, index) => {
        const platform = movingPlatforms[index];
        if (!platform || !Number.isFinite(phase)) return;
        platform.phase = phase;
        const offset = Math.sin(platform.phase) * platform.travel;
        platform.group.position.x = platform.centerX + (platform.axis === 'x' ? offset : 0);
        platform.group.position.z = platform.centerZ + (platform.axis === 'z' ? offset : 0);
        platform.previous.copy(platform.group.position);
      });
    }
    elapsedLevel = Math.max(0, Number(snapshot.elapsedLevel) || 0);
    totalElapsed = Math.max(0, Number(snapshot.totalElapsed) || 0);
    voiceEnabled = snapshot.voiceEnabled !== false;
    voiceIndicator.textContent = voiceEnabled ? 'VOICE: ON · V' : 'VOICE: OFF · V';
    if (Array.isArray(snapshot.cubes)) {
      snapshot.cubes.forEach((savedCube, index) => {
        const cube = cubes[index];
        if (cube && Number.isFinite(savedCube.x) && Number.isFinite(savedCube.z)) {
          cube.group.position.set(savedCube.x, Math.max(0.46, Number(savedCube.y) || 0.46), savedCube.z);
          cube.held = false;
        }
      });
    }
    heldCube = Number.isInteger(snapshot.heldCubeIndex) ? (cubes[snapshot.heldCubeIndex] || null) : null;
    if (heldCube) heldCube.held = true;
    if (relay && snapshot.relayActive) {
      relay.active = true;
      relay.button.material.color.setHex(0x80efc3);
      relay.button.material.emissive.setHex(0x23a77b);
      relay.button.material.emissiveIntensity = 1.3;
    }
    if (snapshot.portals) {
      for (const type of ['blue', 'orange']) {
        const savedPortal = snapshot.portals[type];
        if (savedPortal && Array.isArray(savedPortal.position) && Array.isArray(savedPortal.normal)) {
          createPortal(type, new THREE.Vector3(...savedPortal.position), new THREE.Vector3(...savedPortal.normal));
        }
      }
      scene.updateMatrixWorld(true);
    }
    if (snapshot.doorOpen) {
      doorOpen = true;
      if (exitLift) { exitLift.openAmount = 1; exitLift.targetOpen = 1; }
    }
    if (Number.isInteger(snapshot.currentPlatformIndex) && snapshot.currentPlatformIndex >= 0) {
      currentPlatform = movingPlatforms[snapshot.currentPlatformIndex] || null;
      if (currentPlatform) camera.position.y = currentPlatform.group.position.y + currentPlatform.topOffset + PLAYER.eyeHeight;
    }
    updatePlates();
    hasStarted = true;
    startGame(true);
    showToast('SAVE LOADED · WELCOME BACK', 2.0);
    return true;
  }

  function renderChamberSelect() {
    chamberGrid.replaceChildren();
    LEVELS.forEach((level, index) => {
      const isUnlocked = index <= unlockedLevel || completedLevels.has(index);
      const isComplete = completedLevels.has(index);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `chamber-card${isComplete ? ' completed' : ''}`;
      button.disabled = !isUnlocked;
      const number = document.createElement('span');
      number.className = 'chamber-card-number';
      number.textContent = `TEST ${String(index + 1).padStart(2, '0')}`;
      const name = document.createElement('strong');
      name.textContent = isUnlocked ? level.name : 'LOCKED TEST';
      const story = document.createElement('small');
      story.textContent = isComplete ? '✓ TEST COMPLETE' : isUnlocked ? 'AVAILABLE FOR TESTING' : 'COMPLETE PREVIOUS CHAMBER';
      button.append(number, name, story);
      if (isUnlocked) button.addEventListener('click', () => {
        chamberScreen.classList.add('hidden');
        buildLevel(index);
        hasStarted = false;
        startGame();
      });
      chamberGrid.appendChild(button);
    });
  }

  function renderSaveSlots() {
    autoSaveCard.replaceChildren();
    const autoTitle = document.createElement('strong');
    autoTitle.textContent = 'AUTOSAVE';
    const autoMeta = document.createElement('span');
    autoMeta.textContent = saveData.auto ? `Chamber ${String((saveData.auto.level || 0) + 1).padStart(2, '0')} · ${new Date(saveData.auto.savedAt || Date.now()).toLocaleString('pt-PT')}` : 'Ainda não existe autosave.';
    const autoLoad = document.createElement('button');
    autoLoad.type = 'button'; autoLoad.className = 'slot-action'; autoLoad.textContent = 'LOAD AUTOSAVE';
    autoLoad.disabled = !saveData.auto;
    autoLoad.addEventListener('click', () => {
      if (loadSnapshot(saveData.auto)) saveScreen.classList.add('hidden');
      else saveNotice.textContent = 'Não foi possível carregar este autosave.';
    });
    autoSaveCard.append(autoTitle, autoMeta, autoLoad);

    saveSlots.replaceChildren();
    for (let index = 0; index < SAVE_SLOT_COUNT; index++) {
      const snapshot = saveData.slots[index];
      const card = document.createElement('div');
      card.className = 'save-slot-card';
      const heading = document.createElement('strong'); heading.textContent = `SAVE SLOT ${index + 1}`;
      const meta = document.createElement('span');
      meta.textContent = snapshot ? `${LEVELS[Math.max(0, Math.min(LEVELS.length - 1, snapshot.level || 0))].name} · ${new Date(snapshot.savedAt || Date.now()).toLocaleString('pt-PT')}` : 'EMPTY SLOT';
      const actions = document.createElement('div'); actions.className = 'slot-actions';
      const saveButton = document.createElement('button'); saveButton.type = 'button'; saveButton.className = 'slot-action'; saveButton.textContent = snapshot ? 'OVERWRITE' : 'SAVE HERE';
      saveButton.addEventListener('click', () => {
        saveData.slots[index] = captureSnapshot();
        const ok = writeSaveData();
        saveNotice.textContent = ok ? `Jogo guardado no slot ${index + 1}.` : 'O navegador bloqueou o armazenamento local.';
        renderSaveSlots();
      });
      const loadButton = document.createElement('button'); loadButton.type = 'button'; loadButton.className = 'slot-action secondary'; loadButton.textContent = 'LOAD'; loadButton.disabled = !snapshot;
      loadButton.addEventListener('click', () => {
        if (loadSnapshot(saveData.slots[index])) saveScreen.classList.add('hidden');
        else saveNotice.textContent = 'Este save não pôde ser carregado.';
      });
      actions.append(saveButton, loadButton);
      card.append(heading, meta, actions);
      saveSlots.appendChild(card);
    }
  }

  function showChapterSelect() {
    startScreen.classList.add('hidden');
    saveScreen.classList.add('hidden');
    chamberScreen.classList.remove('hidden');
    renderChamberSelect();
  }

  function showSaveManager(fromPause = false) {
    saveManagerReturnToPause = fromPause;
    if (fromPause) {
      isPlaying = false;
      if (document.pointerLockElement) document.exitPointerLock();
      pauseScreen.classList.add('hidden');
    }
    startScreen.classList.add('hidden');
    chamberScreen.classList.add('hidden');
    saveScreen.classList.remove('hidden');
    saveNotice.textContent = '';
    renderSaveSlots();
  }

  saveData = readSaveData();
  unlockedLevel = saveData.unlockedLevel;
  completedLevels = new Set(saveData.completedLevels);

  function clearLevelObjects() {
    // Libertar também as texturas temporárias dos portais da câmara anterior.
    for (const portal of [portals.blue, portals.orange]) portal?.renderTarget?.dispose();
    // Remove tudo o que pertence à câmara anterior para não acumular objetos.
    for (const object of [...levelObjects]) {
      if (object.parent) object.parent.remove(object);
      object.traverse?.(child => {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          if (Array.isArray(child.material)) child.material.forEach(material => material.dispose());
          else child.material.dispose();
        }
      });
    }
    levelObjects = [];
    portalTargets = [];
    raycastBlockers = [];
    interactables = [];
    colliders = [];
    cubes = [];
    plates = [];
    launchPads = [];
    hazards = [];
    gelPatches = [];
    movingPlatforms = [];
    toxicPools = [];
    currentPlatform = null;
    currentGelType = null;
    gelBounceCooldown = 0;
    portals = { blue: null, orange: null };
    heldCube = null;
    doorGroup = null;
    doorPanel = null;
    entryLift = null;
    exitLift = null;
    liftSequence = null;
  }

  // ------------------------------
  // 5. CONSTRUÇÃO DA SALA 3D
  // ------------------------------
  function addPortalSurface(width, height, x, y, z, normal) {
    // Um painel discreto indica as superfícies onde os portais podem ser colocados.
    const material = makeMaterial(0x334957, 0.5, 0.18, { emissive: 0x071722, emissiveIntensity: 0.35 });
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(width, height), material);
    panel.position.set(x, y, z);
    panel.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal.clone().normalize());
    panel.userData.portalSurface = true;
    panel.userData.normal = normal.clone().normalize();
    panel.receiveShadow = true;
    scene.add(panel);
    portalTargets.push(panel);
    levelObjects.push(panel);

    // Pequenos marcadores luminosos identificam o painel sem tapar o local de tiro.
    const markerMat = makeMaterial(0x7c9aa8, 0.5, 0.2, { emissive: 0x1b5368, emissiveIntensity: 0.6 });
    const marker = new THREE.Mesh(new THREE.BoxGeometry(0.06, height - 0.3, 0.045), markerMat);
    marker.position.copy(panel.position).addScaledVector(normal, 0.035);
    marker.quaternion.copy(panel.quaternion);
    scene.add(marker);
    levelObjects.push(marker);
  }

  function buildRoom(level) {
    const wallMat = texturedMaterial(0xffffff, 'wall', 2.2, 1.4, 0.82, 0.02);
    const wallShade = texturedMaterial(0x8799a1, 'metal', 2.5, 1.2, 0.78, 0.12);
    const floorMat = texturedMaterial(0xffffff, 'floor', 7, 7, 0.92, 0.08);
    const ceilingMat = texturedMaterial(0xe6edef, 'ceiling', 5, 3, 0.88, 0.02);
    const trimMat = makeMaterial(0x1e303a, 0.48, 0.4);
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xe2fbff });

    // Chão, teto e paredes exteriores.
    raycastBlockers.push(addBox(ROOM.halfX * 2, 0.5, ROOM.halfZ * 2, floorMat, 0, -0.25, 0));
    raycastBlockers.push(addBox(ROOM.halfX * 2, 0.3, ROOM.halfZ * 2, ceilingMat, 0, ROOM.height + 0.15, 0));
    raycastBlockers.push(addBox(0.5, ROOM.height, ROOM.halfZ * 2, wallMat, -ROOM.halfX, ROOM.height / 2, 0));
    raycastBlockers.push(addBox(0.5, ROOM.height, ROOM.halfZ * 2, wallMat, ROOM.halfX, ROOM.height / 2, 0));
    raycastBlockers.push(addBox(ROOM.halfX * 2, ROOM.height, 0.5, wallMat, 0, ROOM.height / 2, -ROOM.halfZ));
    raycastBlockers.push(addBox(ROOM.halfX * 2, ROOM.height, 0.5, wallMat, 0, ROOM.height / 2, ROOM.halfZ));

    // A divisória central tem duas secções sólidas e uma passagem larga ao meio.
    // Assim, as alas continuam visualmente separadas, mas nunca ficam isoladas.
    const dividerSegment = ROOM.halfZ - WALKWAY.halfWidth;
    const dividerCenter = (ROOM.halfZ + WALKWAY.halfWidth) / 2;
    for (const side of [-1, 1]) {
      const segment = addBox(0.42, ROOM.height, dividerSegment, wallShade, 0, ROOM.height / 2, side * dividerCenter);
      raycastBlockers.push(segment);
    }
    // Cabeçalho alto da passagem: deixa 3,8 m livres para o jogador e para os cubos.
    const lintel = addBox(0.46, ROOM.height - WALKWAY.clearance, WALKWAY.halfWidth * 2 + 0.3,
      wallShade, 0, WALKWAY.clearance + (ROOM.height - WALKWAY.clearance) / 2, 0);
    raycastBlockers.push(lintel);

    // Pórtico industrial e iluminação da galeria central.
    const portalFrameMat = makeMaterial(0x344852, 0.42, 0.72);
    const guideMat = makeMaterial(level.accent, 0.32, 0.42, { emissive: level.accent, emissiveIntensity: 0.75 });
    for (const side of [-1, 1]) {
      const post = addBox(0.72, 3.9, 0.28, portalFrameMat, 0, 1.95, side * (WALKWAY.halfWidth + 0.12));
      post.castShadow = true;
      const light = addBox(0.76, 3.45, 0.055, guideMat, 0.02, 1.95, side * (WALKWAY.halfWidth - 0.02));
      light.castShadow = false;
    }
    const archCap = addBox(0.72, 0.42, WALKWAY.halfWidth * 2 + 0.55, portalFrameMat, 0, 4.0, 0);
    archCap.castShadow = true;
    const archGlow = addBox(0.75, 0.055, WALKWAY.halfWidth * 2 - 0.2, guideMat, 0, 3.76, 0);
    archGlow.castShadow = false;
    // Carris luminosos no chão guiam a travessia sem tapar o caminho.
    for (const side of [-1, 1]) {
      const rail = addBox(21.0, 0.025, 0.075, guideMat, 0, 0.025, side * 2.45);
      rail.castShadow = false;
    }
    for (let x = -9; x <= 9; x += 3) {
      const marker = addBox(0.55, 0.028, 0.12, lightMat, x, 0.032, 0);
      marker.castShadow = false;
    }
    const galleryLamp = new THREE.PointLight(level.accent, 0.8, 15, 2);
    galleryLamp.position.set(0, 3.3, 0);
    scene.add(galleryLamp);
    levelObjects.push(galleryLamp);

    // Superfícies de portal nos segmentos laterais da divisória e nas paredes exteriores.
    // Não existe qualquer painel a tapar a passagem central.
    const panelWidth = dividerSegment - 1.0;
    addPortalSurface(panelWidth, 7.6, -0.254, 4.3, -dividerCenter, new THREE.Vector3(-1, 0, 0));
    addPortalSurface(panelWidth, 7.6, -0.254, 4.3, dividerCenter, new THREE.Vector3(-1, 0, 0));
    addPortalSurface(panelWidth, 7.6, 0.254, 4.3, -dividerCenter, new THREE.Vector3(1, 0, 0));
    addPortalSurface(panelWidth, 7.6, 0.254, 4.3, dividerCenter, new THREE.Vector3(1, 0, 0));
    addPortalSurface(23.5, 7.6, 11.72, 4.3, 0, new THREE.Vector3(-1, 0, 0));  // parede direita
    addPortalSurface(23.5, 7.6, -11.72, 4.3, 0, new THREE.Vector3(1, 0, 0));  // parede esquerda
    addPortalSurface(23.5, 7.6, 0, 4.3, -12.72, new THREE.Vector3(0, 0, 1));  // parede do fundo
    addPortalSurface(23.5, 7.6, 0, 4.3, 12.72, new THREE.Vector3(0, 0, -1)); // parede da entrada

    // Linhas no chão e frisos dão escala e ajudam a perceber a profundidade.
    const grid = new THREE.GridHelper(24, 24, 0x8ab3c4, 0x67808d);
    grid.position.y = 0.012;
    grid.material.transparent = true;
    grid.material.opacity = 0.2;
    scene.add(grid);
    levelObjects.push(grid);

    for (let z = -10; z <= 10; z += 5) {
      addBox(0.07, 0.035, 24, trimMat, -11.55, 0.03, z);
      addBox(0.07, 0.035, 24, trimMat, 11.55, 0.03, z);
    }

    // Faixas de luz no teto.
    for (let x = -8; x <= 8; x += 8) {
      const strip = addBox(3.2, 0.06, 0.22, lightMat, x, 9.78, 0);
      strip.castShadow = false;
      const lamp = new THREE.PointLight(0xb8eaff, 0.55, 13, 2);
      lamp.position.set(x, 8.9, 0);
      scene.add(lamp);
      levelObjects.push(lamp);
    }

    // Pequenos detalhes de cor mudam de câmara para câmara.
    const accentMat = makeMaterial(level.accent, 0.46, 0.35, { emissive: level.accent, emissiveIntensity: 0.22 });
    addBox(0.08, 0.22, 24, accentMat, 0, 8.7, 0);

    // Painéis modulares, frisos e condutas dão escala à instalação.
    const seamMat = makeMaterial(0x536772, 0.72, 0.22);
    for (let y = 1.1; y < 9.2; y += 2.2) {
      addBox(23.3, 0.045, 0.055, seamMat, 0, y, -12.71);
      addBox(23.3, 0.045, 0.055, seamMat, 0, y, 12.71);
      addBox(0.055, 0.045, 25.2, seamMat, -11.71, y, 0);
      addBox(0.055, 0.045, 25.2, seamMat, 11.71, y, 0);
    }
    for (let x = -8; x <= 8; x += 4) {
      for (let z = -9; z <= 9; z += 6) {
        const floorMark = addBox(0.08, 0.018, 1.25, accentMat, x, 0.018, z);
        floorMark.castShadow = false;
      }
    }
    // Painéis escuros de manutenção com grelhas metálicas.
    for (const side of [-1, 1]) {
      const panel = addBox(0.12, 1.35, 2.6, trimMat, side * 11.67, 5.25, 0);
      panel.castShadow = false;
      for (let j = 0; j < 7; j++) {
        const vent = addBox(0.035, 0.045, 2.25, seamMat, side * 11.59, 4.78 + j * 0.15, 0);
        vent.castShadow = false;
      }
    }
    const ceilingRailMat = makeMaterial(0x6b7e87, 0.62, 0.34);
    for (const z of [-8, 8]) {
      const rail = addBox(22.8, 0.12, 0.16, ceilingRailMat, 0, 9.48, z);
      rail.castShadow = false;
    }

    // Elementos sólidos que servem de obstáculos e também de decoração.
    for (const obstacle of level.obstacles) {
      const crateMat = makeMaterial(0x657984, 0.72, 0.18);
      const crate = addBox(obstacle.w, obstacle.h, obstacle.d, crateMat, obstacle.x, obstacle.h / 2, obstacle.z);
      raycastBlockers.push(crate);
      addCollider(obstacle.x, obstacle.z, obstacle.w, obstacle.d, 0, obstacle.h);
      // Contorno superior da caixa.
      const topLine = addBox(obstacle.w + 0.06, 0.07, obstacle.d + 0.06, accentMat, obstacle.x, obstacle.h + 0.03, obstacle.z);
      topLine.castShadow = false;
      crate.userData.obstacle = true;
    }

    // Painéis adicionais colocados pelo editor: são superfícies válidas para os portais.
    for (const customPanel of (level.portalPanels || [])) {
      const rotation = ((Number(customPanel.rotation) || 0) % 4 + 4) % 4;
      const normal = rotation === 0 ? new THREE.Vector3(0, 0, 1)
        : rotation === 1 ? new THREE.Vector3(1, 0, 0)
        : rotation === 2 ? new THREE.Vector3(0, 0, -1) : new THREE.Vector3(-1, 0, 0);
      const panelWidth = 3.2;
      if (Math.abs(normal.z) > 0.5) {
        const backing = addBox(panelWidth, 3.9, 0.24, wallShade, customPanel.x, 1.95, customPanel.z);
        raycastBlockers.push(backing); addCollider(customPanel.x, customPanel.z, panelWidth, 0.3, 0, 3.9);
      } else {
        const backing = addBox(0.24, 3.9, panelWidth, wallShade, customPanel.x, 1.95, customPanel.z);
        raycastBlockers.push(backing); addCollider(customPanel.x, customPanel.z, 0.3, panelWidth, 0, 3.9);
      }
      const surfacePosition = new THREE.Vector3(customPanel.x, 2.0, customPanel.z).addScaledVector(normal, 0.13);
      addPortalSurface(2.65, 3.3, surfacePosition.x, surfacePosition.y, surfacePosition.z, normal);
    }
  }

  // Elementos industriais adicionais para quebrar a sensação de sala vazia.
  function addChamberDetails(level) {
    const frameMat = makeMaterial(0x344852, 0.48, 0.72);
    const steelMat = texturedMaterial(0xe1e8e9, 'metal', 1.4, 1.4, 0.38, 0.68);
    const darkMat = makeMaterial(0x111d25, 0.42, 0.62);
    const glowMat = new THREE.MeshBasicMaterial({ color: 0x9cecff });
    const accentMat = makeMaterial(level.accent, 0.35, 0.5, { emissive: level.accent, emissiveIntensity: 0.28 });

    // Pilares estruturais reforçados nos quatro cantos da câmara.
    for (const x of [-11.42, 11.42]) {
      for (const z of [-12.35, 12.35]) {
        const pillar = new THREE.Group();
        pillar.position.set(x, 0, z);
        const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.34, 9.2, 0.34), steelMat);
        shaft.position.y = 4.6; shaft.castShadow = true; shaft.receiveShadow = true; pillar.add(shaft);
        const foot = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.26, 0.55), frameMat);
        foot.position.y = 0.13; pillar.add(foot);
        const cap = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.24, 0.55), frameMat);
        cap.position.y = 9.12; pillar.add(cap);
        for (let y = 1.0; y < 8.6; y += 1.6) {
          const bolt = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), darkMat);
          bolt.position.set(-0.176, y, 0.12); pillar.add(bolt);
        }
        scene.add(pillar); levelObjects.push(pillar);
      }
    }

    // Câmaras de observação: corpo metálico, suporte e lente azul.
    for (const [x, z, angle] of [[-10.9,-11.95,0.55],[10.9,-11.95,-0.55],[-10.9,11.95,2.6],[10.9,11.95,-2.6]]) {
      const cameraProp = new THREE.Group();
      cameraProp.position.set(x, 8.35, z);
      cameraProp.rotation.y = angle;
      const mount = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.34, 0.14), frameMat);
      mount.position.y = 0.3; cameraProp.add(mount);
      const housing = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 0.46, 24), steelMat);
      housing.rotation.x = Math.PI / 2; housing.position.z = -0.12; cameraProp.add(housing);
      const lensRing = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.028, 8, 24), accentMat);
      lensRing.position.z = -0.37; cameraProp.add(lensRing);
      const lens = new THREE.Mesh(new THREE.SphereGeometry(0.084, 18, 12), glowMat);
      lens.position.z = -0.38; cameraProp.add(lens);
      scene.add(cameraProp); levelObjects.push(cameraProp);
    }

    // Luminárias com caixa, difusor e luz local para criar poças de luz realistas.
    for (const z of [-8, 0, 8]) {
      const lampGroup = new THREE.Group();
      lampGroup.position.set(0, 9.55, z);
      const housing = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.18, 1.05), darkMat);
      housing.position.y = 0.02; lampGroup.add(housing);
      const diffuser = new THREE.Mesh(new THREE.BoxGeometry(3.15, 0.045, 0.72), glowMat);
      diffuser.position.y = -0.09; lampGroup.add(diffuser);
      const frame = new THREE.Mesh(new THREE.BoxGeometry(3.7, 0.045, 1.12), frameMat);
      frame.position.y = 0.12; lampGroup.add(frame);
      scene.add(lampGroup); levelObjects.push(lampGroup);
      const localLight = new THREE.PointLight(0xd7f3ff, 0.78, 15, 2);
      localLight.position.set(0, 8.95, z);
      scene.add(localLight); levelObjects.push(localLight);
    }

    // Condutas grossas seguem as paredes e tornam a escala da instalação mais credível.
    for (const side of [-1, 1]) {
      const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 22.5, 12), steelMat);
      pipe.rotation.x = Math.PI / 2;
      pipe.position.set(side * 11.43, 8.85, 0);
      pipe.castShadow = true; scene.add(pipe); levelObjects.push(pipe);
      const lowerPipe = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 22.5, 10), frameMat);
      lowerPipe.rotation.x = Math.PI / 2;
      lowerPipe.position.set(side * 11.50, 8.55, 0);
      scene.add(lowerPipe); levelObjects.push(lowerPipe);
    }

    // Placa técnica com identificação da câmara, posicionada numa zona alta da parede.
    const decal = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 1.05),
      new THREE.MeshBasicMaterial({ map: makeApertureDecalTexture(`Test Chamber 0${currentLevel + 1}`, 'Authorized Testing Personnel Only'), toneMapped: false })
    );
    decal.position.set(11.43, 7.25, -9.0);
    decal.rotation.y = -Math.PI / 2;
    scene.add(decal); levelObjects.push(decal);

    // Marcas de segurança no chão: amarelo/preto e pequenos parafusos de fixação.
    const stripeMat = makeMaterial(0xd8a83c, 0.72, 0.18);
    const blackStripe = makeMaterial(0x171e22, 0.82, 0.12);
    for (let i = 0; i < 12; i++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.018, 0.11), i % 2 ? stripeMat : blackStripe);
      stripe.position.set(10.5, 0.018, -5.5 + i * 0.42);
      scene.add(stripe); levelObjects.push(stripe);
    }

    // Um pequeno painel de manutenção na parede, com grelha e luz de estado.
    const servicePanel = new THREE.Group();
    servicePanel.position.set(-11.38, 5.5, 8.8);
    servicePanel.rotation.y = Math.PI / 2;
    const panelBase = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.3, 0.16), darkMat);
    servicePanel.add(panelBase);
    for (let i = 0; i < 8; i++) {
      const vent = new THREE.Mesh(new THREE.BoxGeometry(1.28, 0.035, 0.035), steelMat);
      vent.position.set(0, -0.42 + i * 0.12, 0.1); servicePanel.add(vent);
    }
    const statusLight = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 8), accentMat);
    statusLight.position.set(0.58, 0.42, 0.12); servicePanel.add(statusLight);
    scene.add(servicePanel); levelObjects.push(servicePanel);
  }

  // ------------------------------
  // 6. PORTAIS E TELETRANSPORTE
  // ------------------------------
  function removePortal(type) {
    if (!portals[type]) return;
    const group = portals[type].group;
    portals[type].renderTarget?.dispose();
    scene.remove(group);
    group.traverse(child => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(material => material.dispose());
        else child.material.dispose();
      }
    });
    portals[type] = null;
  }

  function createPortal(type, position, normal) {
    removePortal(type);
    const isBlue = type === 'blue';
    const color = isBlue ? 0x25c5ff : 0xff8a3b;
    const glow = isBlue ? 0x0e9bd8 : 0xe85a18;
    const group = new THREE.Group();
    group.position.copy(position);
    group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal.clone().normalize());
    group.userData.portalType = type;

    const darkFrame = makeMaterial(0x0b1820, 0.3, 0.82);
    const frameMat = makeMaterial(color, 0.22, 0.48, { emissive: glow, emissiveIntensity: 2.0 });
    const renderTarget = new THREE.WebGLRenderTarget(488, 1024, {
      minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat, depthBuffer: true, stencilBuffer: false
    });
    renderTarget.texture.generateMipmaps = false;
    const surfaceMat = new THREE.MeshBasicMaterial({ map: renderTarget.texture, side: THREE.DoubleSide, toneMapped: false });
    const width = PORTAL.width;
    const height = PORTAL.height;
    const rx = width / 2;
    const ry = height / 2;

    // O painel escuro é um oval vertical, não um retângulo com moldura.
    const backShape = new THREE.Shape();
    backShape.absellipse(0, 0, rx + 0.14, ry + 0.14, 0, Math.PI * 2, false, 0);
    const backing = new THREE.Mesh(new THREE.ShapeGeometry(backShape, 72), darkFrame);
    backing.position.z = -0.075;
    group.add(backing);

    // A abertura tem o topo arredondado e a base cortada pelo chão, para permitir
    // que a cápsula do jogador passe sem ficar presa no vértice inferior de um oval.
    const apertureShape = new THREE.Shape();
    apertureShape.moveTo(-rx, -ry);
    apertureShape.lineTo(-rx, -0.48);
    apertureShape.quadraticCurveTo(-rx, ry, 0, ry);
    apertureShape.quadraticCurveTo(rx, ry, rx, -0.48);
    apertureShape.lineTo(rx, -ry);
    apertureShape.closePath();
    const surface = new THREE.Mesh(new THREE.ShapeGeometry(apertureShape, 72), surfaceMat);
    surface.position.z = 0.045;
    surface.userData.isPortalView = true;
    group.add(surface);

    // Aro oval em metal e luz azul/laranja, semelhante às aberturas do jogo original.
    const outerRing = new THREE.Mesh(new THREE.TorusGeometry(1, 0.115, 14, 96), darkFrame);
    outerRing.scale.set(rx + 0.10, ry + 0.10, 1);
    outerRing.position.z = 0.018;
    group.add(outerRing);
    const glowRing = new THREE.Mesh(new THREE.TorusGeometry(1, 0.045, 12, 96), frameMat);
    glowRing.scale.set(rx + 0.07, ry + 0.07, 1);
    glowRing.position.z = 0.085;
    group.add(glowRing);
    const innerRing = new THREE.Mesh(new THREE.TorusGeometry(1, 0.014, 8, 96), new THREE.MeshBasicMaterial({ color: 0xf1fbff, transparent: true, opacity: 0.72 }));
    innerRing.scale.set(rx - 0.035, ry - 0.035, 1);
    innerRing.position.z = 0.095;
    group.add(innerRing);

    // Pequenos emissores laterais dão volume à moldura sem esconder a abertura.
    for (const side of [-1, 1]) {
      const emitter = new THREE.Mesh(new THREE.SphereGeometry(0.065, 16, 12), frameMat);
      emitter.position.set(side * (rx + 0.10), 0, 0.11);
      group.add(emitter);
      const bolt = new THREE.Mesh(new THREE.SphereGeometry(0.026, 10, 8), makeMaterial(0xd5e2e6, 0.28, 0.82));
      bolt.position.set(side * (rx + 0.10), ry * 0.58, 0.105);
      group.add(bolt);
    }

    const portalLight = new THREE.PointLight(color, 1.6, 6.5, 2);
    portalLight.position.set(0, 0.1, 0.38);
    group.add(portalLight);

    scene.add(group);
    group.updateMatrixWorld(true);
    levelObjects.push(group);
    const viewCamera = new THREE.PerspectiveCamera(camera.fov, width / height, 0.05, 180);
    portals[type] = { group, normal: normal.clone().normalize(), ringA: glowRing, ringB: innerRing, type, surface, renderTarget, viewCamera };
  }

  function setDefaultPortals(level) {
    // Alinhamos os portais com a zona de entrada de cada teste para o primeiro percurso ser claro.
    const portalZ = level.spawn?.z ?? 0;
    createPortal('blue', new THREE.Vector3(0.31, PORTAL.centerY, portalZ), new THREE.Vector3(1, 0, 0));
    createPortal('orange', new THREE.Vector3(-11.665, PORTAL.centerY, portalZ), new THREE.Vector3(1, 0, 0));
  }

  function shootPortal(type) {
    if (!isPlaying || levelFinished) return;
    raycaster.setFromCamera(screenCenter, camera);
    // Os blocos sólidos também entram no raio: não podes disparar através
    // de uma parede ou de uma caixa para acertar num painel escondido.
    const hits = raycaster.intersectObjects([...portalTargets, ...raycastBlockers], false);
    if (!hits.length || !hits[0].object.userData.portalSurface) {
      showToast('DISPARO BLOQUEADO — aponta para um painel de teste visível.');
      playTone(130, 0.08, 'square', 0.025);
      return;
    }

    const hit = hits[0];
    const normal = hit.object.userData.normal.clone();
    // Mantém sempre o portal à altura do chão: a abertura tem de caber no corpo todo.
    const centerY = PORTAL.centerY;
    const position = hit.point.clone();
    position.y = centerY;
    position.addScaledVector(normal, 0.055);

    // Evita colocar um portal demasiado perto de um canto ou de outro portal.
    if (Math.abs(hit.point.y - 4.3) > 3.8) {
      showToast('Aponta para o painel de teste.');
      return;
    }
    createPortal(type, position, normal);
    playTone(type === 'blue' ? 570 : 380, 0.2, 'sine', 0.055);
    showToast(type === 'blue' ? 'PORTAL AZUL POSICIONADO' : 'PORTAL LARANJA POSICIONADO', 1.25);
  }

  function attemptPortalTeleport(oldPosition, nextPosition) {
    if (portalCooldown > 0 || !portals.blue || !portals.orange) return null;

    const entries = [portals.blue, portals.orange];
    for (const entry of entries) {
      const exit = entry.type === 'blue' ? portals.orange : portals.blue;
      if (!exit) continue;

      // Converte a posição para as coordenadas locais do portal.
      const oldLocal = entry.group.worldToLocal(oldPosition.clone());
      const nextLocal = entry.group.worldToLocal(nextPosition.clone());
      const crossedFrontToBack = oldLocal.z > 0 && nextLocal.z <= 0;
      const bodyBottom = nextPosition.y - PLAYER.eyeHeight;
      const bodyTop = bodyBottom + PLAYER.height;
      const portalBottom = entry.group.position.y - PORTAL.height / 2;
      const portalTop = entry.group.position.y + PORTAL.height / 2;
      const insideOpening = Math.abs(nextLocal.x) < PORTAL.width / 2 - PLAYER.radius * 0.52
        && bodyBottom >= portalBottom - 0.12
        && bodyTop <= portalTop + 0.12;

      if (!crossedFrontToBack || !insideOpening) continue;

      // Rodar 180 graus dentro do portal faz o jogador sair a olhar para fora.
      const exitLocal = new THREE.Vector3(-nextLocal.x, nextLocal.y, -nextLocal.z + 0.95);
      const destination = exit.group.localToWorld(exitLocal);

      // A direção da câmara acompanha a rotação entre a entrada e a saída.
      camera.getWorldDirection(forwardVector);
      const transformedDirection = forwardVector.clone()
        .applyQuaternion(entry.group.quaternion.clone().invert());
      transformedDirection.x *= -1;
      transformedDirection.z *= -1;
      transformedDirection.applyQuaternion(exit.group.quaternion).normalize();
      // A câmara olha para o eixo -Z local; por isso o sinal de X é invertido ao reconstruir o yaw.
      yaw = Math.atan2(-transformedDirection.x, -transformedDirection.z);
      pitch = Math.asin(THREE.MathUtils.clamp(transformedDirection.y, -1, 1));
      camera.rotation.set(pitch, yaw, 0, 'YXZ');

      // A velocidade vertical mantém-se; a horizontal também muda de direção.
      const localVelocity = playerVelocity.clone().applyQuaternion(entry.group.quaternion.clone().invert());
      localVelocity.x *= -1;
      localVelocity.z *= -1;
      playerVelocity.copy(localVelocity.applyQuaternion(exit.group.quaternion));

      portalCooldown = 0.42;
      playTone(720, 0.13, 'sine', 0.04);
      return destination;
    }
    return null;
  }

  // Renderiza a sala do outro lado de cada portal para dentro da respetiva superfície.
  // A câmara virtual fica do outro lado da parede; o plano de recorte abre visualmente o buraco.
  const portalHalfTurn = new THREE.Matrix4().makeRotationY(Math.PI);
  function updatePortalViews() {
    if (!portals.blue || !portals.orange) return;
    scene.updateMatrixWorld(true);
    camera.updateMatrixWorld(true);
    const oldTarget = renderer.getRenderTarget();
    const oldClippingPlanes = renderer.clippingPlanes;
    const blueVisible = portals.blue.surface.visible;
    const orangeVisible = portals.orange.surface.visible;

    // Evita que um portal desenhe a textura do outro dentro da própria textura.
    portals.blue.surface.visible = false;
    portals.orange.surface.visible = false;

    for (const entry of [portals.blue, portals.orange]) {
      const exit = entry.type === 'blue' ? portals.orange : portals.blue;
      if (!exit || !entry.renderTarget || !entry.viewCamera) continue;

      const inverseEntry = new THREE.Matrix4().copy(entry.group.matrixWorld).invert();
      const portalTransform = new THREE.Matrix4()
        .multiplyMatrices(exit.group.matrixWorld, portalHalfTurn)
        .multiply(inverseEntry);
      const virtualWorld = new THREE.Matrix4().multiplyMatrices(portalTransform, camera.matrixWorld);
      const virtualCamera = entry.viewCamera;
      virtualCamera.position.setFromMatrixPosition(virtualWorld);
      virtualCamera.quaternion.setFromRotationMatrix(virtualWorld);
      virtualCamera.scale.set(1, 1, 1);
      virtualCamera.fov = camera.fov;
      virtualCamera.aspect = PORTAL.width / PORTAL.height;
      virtualCamera.near = camera.near;
      virtualCamera.far = camera.far;
      virtualCamera.updateProjectionMatrix();
      virtualCamera.updateMatrixWorld(true);

      // Mantém o lado da sala e corta a parede entre a câmara virtual e a saída.
      const clipPlane = new THREE.Plane(exit.normal.clone(), -exit.normal.dot(exit.group.position) - 0.12);
      renderer.clippingPlanes = [clipPlane];
      renderer.setRenderTarget(entry.renderTarget);
      renderer.clear(true, true, true);
      renderer.render(scene, virtualCamera);
    }

    portals.blue.surface.visible = blueVisible;
    portals.orange.surface.visible = orangeVisible;
    renderer.clippingPlanes = oldClippingPlanes || [];
    renderer.setRenderTarget(oldTarget);
  }

  // ------------------------------
  // 7. CUBOS, BOTÕES E RELÉ
  // ------------------------------
  function makeCube(x, z, index) {
    const group = new THREE.Group();
    group.position.set(x, 0.46, z);
    const cubeMat = texturedMaterial(index % 2 === 0 ? 0xffffff : 0xdde8ec, 'metal', 1, 1, 0.42, 0.42);
    const cube = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.88, 0.88), cubeMat);
    cube.castShadow = true;
    cube.receiveShadow = true;
    group.add(cube);

    // Linhas azuis e pequenos cantos metálicos dão ao cubo um aspeto tecnológico.
    const stripeMat = makeMaterial(0x3cbbe8, 0.34, 0.45, { emissive: 0x145a79, emissiveIntensity: 0.55 });
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.91, 0.12, 0.91), stripeMat);
    stripe.position.y = 0.05;
    group.add(stripe);
    const cubeDark = makeMaterial(0x1b2c35, 0.34, 0.72);
    const cubeLight = makeMaterial(0xdce8eb, 0.28, 0.56);
    // Molduras e cantos em relevo fazem o cubo parecer uma peça mecânica montada.
    for (const signX of [-1, 1]) for (const signY of [-1, 1]) for (const signZ of [-1, 1]) {
      const corner = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 10), cubeLight);
      corner.position.set(signX * 0.405, signY * 0.405, signZ * 0.405);
      group.add(corner);
    }
    for (const side of [-1, 1]) {
      const facePlate = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.62, 0.025), cubeDark);
      facePlate.position.z = side * 0.447;
      group.add(facePlate);
      const faceRing = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.025, 8, 28), stripeMat);
      faceRing.position.z = side * 0.467;
      group.add(faceRing);
      const center = new THREE.Mesh(new THREE.CircleGeometry(0.115, 24), cubeLight);
      center.position.z = side * 0.469;
      group.add(center);
      const badge = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.02), stripeMat);
      badge.position.set(0, 0, side * 0.486);
      group.add(badge);
    }

    scene.add(group);
    levelObjects.push(group);
    const item = { group, mesh: cube, held: false, verticalSpeed: 0, index };
    cubes.push(item);
    interactables.push(cube);
    cube.userData.kind = 'cube';
    cube.userData.item = item;
    return item;
  }

  function makePlate(x, z, index) {
    const group = new THREE.Group();
    group.position.set(x, 0.04, z);
    const baseMat = makeMaterial(0x263640, 0.7, 0.32);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.02, 0.12, 36), baseMat);
    base.position.y = 0.06;
    group.add(base);
    const ringMat = makeMaterial(0x5d8190, 0.34, 0.42, { emissive: 0x103346, emissiveIntensity: 0.45 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.77, 0.055, 8, 40), ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.16;
    group.add(ring);
    const centerMat = makeMaterial(0x526875, 0.5, 0.2);
    const center = new THREE.Mesh(new THREE.CylinderGeometry(0.56, 0.56, 0.08, 32), centerMat);
    center.position.y = 0.15;
    group.add(center);
    scene.add(group);
    levelObjects.push(group);
    plates.push({ group, ring, center, x, z, active: false, index });
  }

  // Plataforma de impulso: lança o jogador verticalmente quando é pisada.
  function makeLaunchPad(x, z) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.82, 0.9, 0.16, 40), makeMaterial(0x263a44, 0.4, 0.72));
    base.position.y = 0.08; base.castShadow = true; base.receiveShadow = true; group.add(base);
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.67, 0.72, 0.08, 40), makeMaterial(0x65818b, 0.35, 0.48));
    pad.position.y = 0.19; group.add(pad);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.055, 10, 48), makeMaterial(0x4bc7ee, 0.28, 0.42, { emissive: 0x1379a0, emissiveIntensity: 1.15 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.25; group.add(ring);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0xc8f7ff });
    for (let i = 0; i < 3; i++) {
      const arrow = new THREE.Mesh(new THREE.ConeGeometry(0.105, 0.24, 3), arrowMat);
      arrow.rotation.z = Math.PI;
      arrow.position.set(0, 0.28, -0.27 + i * 0.26);
      group.add(arrow);
    }
    scene.add(group); levelObjects.push(group);
    launchPads.push({ x, z, group, ring });
  }

  // Grelha vermelha de segurança: tocar nela repõe o jogador no início da câmara.
  function makeHazard(x, z) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    const base = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.045, 2.0), makeMaterial(0x1b252a, 0.52, 0.6));
    base.position.y = 0.035; group.add(base);
    const redMat = makeMaterial(0xff3e32, 0.32, 0.22, { emissive: 0x9f100b, emissiveIntensity: 1.35 });
    for (let i = -4; i <= 4; i++) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.035, 1.78), redMat);
      bar.position.set(i * 0.19, 0.07, 0); group.add(bar);
    }
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.035, 8, 48), makeMaterial(0xff6c42, 0.35, 0.2, { emissive: 0x8d1d11, emissiveIntensity: 0.9 }));
    rim.rotation.x = Math.PI / 2; rim.position.y = 0.075; group.add(rim);
    scene.add(group); levelObjects.push(group);
    hazards.push({ x, z, radius: 0.92, group });
  }


  // Tinta viscosa e brilhante: manchas irregulares em relevo quase plano.
  // O acabamento clearcoat imita a superfície molhada dos gels de Portal.
  function makeGelPatch(type, x, z, width, depth) {
    const group = new THREE.Group();
    group.position.set(x, 0.038, z);
    const isSpeed = type === 'speed';
    const color = isSpeed ? 0xf08a2f : 0x27b9ee;
    const gelMaterial = new THREE.MeshPhysicalMaterial({
      color, roughness: 0.105, metalness: 0.015, clearcoat: 1,
      clearcoatRoughness: 0.035, transparent: true, opacity: 0.96
    });
    const puddle = new THREE.Mesh(new THREE.CircleGeometry(1, 64), gelMaterial);
    puddle.rotation.x = -Math.PI / 2;
    puddle.scale.set(width * 0.47, depth * 0.46, 1);
    puddle.position.y = 0.004;
    puddle.receiveShadow = true;
    group.add(puddle);

    // Pequenos salpicos em torno da poça principal criam contornos orgânicos.
    const splats = [
      [-0.34, -0.30, 0.24, 0.18], [0.36, -0.22, 0.20, 0.14],
      [-0.38, 0.27, 0.17, 0.13], [0.31, 0.34, 0.23, 0.16],
      [0.02, -0.45, 0.12, 0.18], [-0.08, 0.43, 0.14, 0.12]
    ];
    splats.forEach(([sx, sz, sw, sd], i) => {
      const blob = new THREE.Mesh(new THREE.CircleGeometry(1, 32), gelMaterial);
      blob.rotation.x = -Math.PI / 2;
      blob.scale.set(width * sw, depth * sd, 1);
      blob.position.set(sx * width, 0.006 + i * 0.0003, sz * depth);
      group.add(blob);
    });
    // Reflexos finos e brancos dão leitura de líquido glossy sem textura externa.
    const gloss = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.23, depthWrite: false });
    for (let i = 0; i < 3; i++) {
      const streak = new THREE.Mesh(new THREE.CircleGeometry(1, 24), gloss);
      streak.rotation.x = -Math.PI / 2;
      streak.rotation.z = -0.28 + i * 0.25;
      streak.scale.set(width * (0.12 - i * 0.018), depth * 0.018, 1);
      streak.position.set((-0.18 + i * 0.17) * width, 0.009 + i * 0.0003, -0.05 * depth);
      group.add(streak);
    }
    scene.add(group);
    levelObjects.push(group);
    gelPatches.push({ type, x, z, halfW: width * 0.47, halfD: depth * 0.46, group });
  }

  // Plataformas cinéticas que oscilam entre dois extremos.
  // O jogador pode saltar para cima delas e é transportado com a plataforma.
  function makeMovingPlatform(config, index) {
    const width = config.width || 3;
    const depth = config.depth || 2.3;
    const height = 0.34;
    const group = new THREE.Group();
    const baseMaterial = texturedMaterial(0x87969a, 'metal', 1.4, 1.2, 0.42, 0.66);
    const darkMaterial = makeMaterial(0x17252c, 0.42, 0.72);
    const lightMaterial = makeMaterial(0x54d5f3, 0.28, 0.36, { emissive: 0x1685a3, emissiveIntensity: 0.85 });
    const base = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), baseMaterial);
    base.castShadow = true; base.receiveShadow = true; group.add(base);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(width - 0.16, 0.055, depth - 0.16), makeMaterial(0x465b63, 0.58, 0.62));
    deck.position.y = height / 2 + 0.03; deck.receiveShadow = true; group.add(deck);
    for (const side of [-1, 1]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(width - 0.12, 0.055, 0.055), lightMaterial);
      rail.position.set(0, height / 2 + 0.07, side * (depth / 2 - 0.08)); group.add(rail);
      const bumper = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.13, depth), darkMaterial);
      bumper.position.x = side * (width / 2 - 0.04); group.add(bumper);
    }
    for (let i = -1; i <= 1; i++) {
      const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.018, 12), darkMaterial);
      bolt.rotation.x = Math.PI / 2;
      bolt.position.set(i * width * 0.31, height / 2 + 0.065, 0); group.add(bolt);
    }
    const guide = new THREE.Mesh(new THREE.BoxGeometry(width + 1.2, 0.08, depth + 0.7), darkMaterial);
    guide.position.y = -height / 2 - 0.14; group.add(guide);
    group.position.set(config.x, config.y || 0.5, config.z);
    scene.add(group); levelObjects.push(group);
    const platform = {
      group, width, depth, topOffset: height / 2 + 0.055,
      axis: config.axis === 'z' ? 'z' : 'x', travel: config.travel || 2,
      speed: config.speed || 0.65, phase: Number(config.phase) || 0,
      centerX: config.x, centerZ: config.z, baseY: config.y || 0.5,
      previous: group.position.clone(), delta: new THREE.Vector3(), index
    };
    platform.group.position[platform.axis] += Math.sin(platform.phase) * platform.travel;
    platform.previous.copy(platform.group.position);
    movingPlatforms.push(platform);
  }

  function updateMovingPlatforms(dt) {
    for (const platform of movingPlatforms) {
      platform.previous.copy(platform.group.position);
      platform.phase += dt * platform.speed;
      const offset = Math.sin(platform.phase) * platform.travel;
      platform.group.position.x = platform.centerX + (platform.axis === 'x' ? offset : 0);
      platform.group.position.z = platform.centerZ + (platform.axis === 'z' ? offset : 0);
      platform.group.position.y = platform.baseY;
      platform.delta.subVectors(platform.group.position, platform.previous);
      if (currentPlatform === platform) camera.position.add(platform.delta);
    }
  }

  // Piscina de fluido tóxico: superfície verde, ondulação e aro de aviso.
  function makeToxicPool(x, z, width, depth) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    const rimMat = makeMaterial(0x253b35, 0.38, 0.62);
    const liquidMat = new THREE.MeshPhysicalMaterial({
      color: 0x39b879, roughness: 0.12, metalness: 0.08, clearcoat: 1,
      clearcoatRoughness: 0.04, transparent: true, opacity: 0.88,
      emissive: 0x0b512e, emissiveIntensity: 0.34
    });
    const basin = new THREE.Mesh(new THREE.BoxGeometry(width, 0.24, depth), rimMat);
    basin.position.y = -0.11; basin.receiveShadow = true; group.add(basin);
    const surface = new THREE.Mesh(new THREE.PlaneGeometry(width - 0.18, depth - 0.18, 1, 1), liquidMat);
    surface.rotation.x = -Math.PI / 2; surface.position.y = 0.035; surface.userData.toxicSurface = true; group.add(surface);
    const warning = makeMaterial(0xe4b53c, 0.65, 0.2);
    for (let i = 0; i < 16; i++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(width / 16 + 0.01, 0.025, 0.16), i % 2 ? warning : rimMat);
      stripe.position.set(-width / 2 + width * (i + 0.5) / 16, 0.055, depth / 2 - 0.02);
      group.add(stripe);
    }
    const ripples = [];
    for (let i = 0; i < 4; i++) {
      const ripple = new THREE.Mesh(new THREE.TorusGeometry(0.32 + i * 0.13, 0.018, 6, 32), new THREE.MeshBasicMaterial({ color: 0x98ffc3, transparent: true, opacity: 0.28 }));
      ripple.rotation.x = Math.PI / 2;
      ripple.position.set((i % 2 ? 1 : -1) * width * 0.19, 0.07 + i * 0.001, (i < 2 ? -1 : 1) * depth * 0.16);
      group.add(ripple); ripples.push(ripple);
    }
    scene.add(group); levelObjects.push(group);
    toxicPools.push({ x, z, halfW: width / 2, halfD: depth / 2, group, surface, ripples, phase: 0 });
  }

  function pointInsidePatch(x, z, patch) {
    return Math.abs(x - patch.x) <= patch.halfW && Math.abs(z - patch.z) <= patch.halfD;
  }

  function makeRelay(position) {
    const group = new THREE.Group();
    group.position.set(position.x, 0, position.z);
    // O relé fica num pedestal para ser fácil de detetar e alcançar.
    const pedestal = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.45, 0.9), makeMaterial(0x526772, 0.72, 0.25));
    pedestal.position.y = 0.72;
    group.add(pedestal);
    const face = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.66, 0.14), makeMaterial(0x1b2d39, 0.42, 0.35));
    face.position.set(0, 1.12, 0.48);
    group.add(face);
    const buttonMat = makeMaterial(0xffa347, 0.28, 0.35, { emissive: 0x8a3d0d, emissiveIntensity: 0.55 });
    const button = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.12, 28), buttonMat);
    button.rotation.x = Math.PI / 2;
    button.position.set(0, 1.12, 0.57);
    group.add(button);
    scene.add(group);
    levelObjects.push(group);
    const relay = { group, button, active: false };
    interactables.push(button);
    button.userData.kind = 'relay';
    button.userData.item = relay;
    return relay;
  }

  let relay = null;

  function updatePlates() {
    // Um cubo colocado perto do centro de uma plataforma ativa-a.
    for (const plate of plates) {
      const occupied = cubes.some(cube => {
        if (cube.held) return false;
        const p = cube.group.position;
        const dx = p.x - plate.x;
        const dz = p.z - plate.z;
        return dx * dx + dz * dz < 0.9 * 0.9 && p.y < 0.95;
      });
      if (occupied !== plate.active) {
        plate.active = occupied;
        plate.center.material.color.setHex(occupied ? 0x7af0c6 : 0x526875);
        plate.center.material.emissive.setHex(occupied ? 0x1d9f79 : 0x000000);
        plate.center.material.emissiveIntensity = occupied ? 1.1 : 0;
        plate.ring.material.emissive.setHex(occupied ? 0x35d5a5 : 0x103346);
        plate.ring.material.emissiveIntensity = occupied ? 1.4 : 0.45;
        if (occupied) { playTone(640, 0.14, 'triangle', 0.035); sayAI('plate'); }
      }
    }

    const completePlates = plates.filter(plate => plate.active).length;
    const allPlates = completePlates === plates.length;
    const relayReady = !relay || relay.active;
    const progress = completePlates + (relayReady && relay ? 1 : 0);
    const total = plates.length + (relay ? 1 : 0);
    progressFill.style.width = `${total ? (progress / total) * 100 : 0}%`;
    progressLabel.textContent = `${completePlates} / ${plates.length} PLATFORMS ACTIVE${relay ? ` · ${relay.active ? 'POWER RESTORED' : 'POWER RELAY PENDING'}` : ''}`;

    if (allPlates && relayReady && !doorOpen) openExitDoor();
  }

  function openExitDoor() {
    doorOpen = true;
    playTone(520, 0.2, 'sine', 0.05);
    setTimeout(() => playTone(780, 0.28, 'sine', 0.04), 130);
    showToast('OBJETIVOS CONCLUÍDOS — A SAÍDA ESTÁ ABERTA!', 3);
    if (exitLift) exitLift.targetOpen = 1;
    sayAI('door');
  }

  // ------------------------------
  // 8. PORTA DE SAÍDA
  // ------------------------------
  function makeExitDoor() {
    // O elevador de saída está embutido na parede oeste. O vão abre quando
    // todos os objetivos estão concluídos e o jogador entra para terminar a fase.
    const normal = new THREE.Vector3(1, 0, 0);
    exitLift = createLiftCabin(new THREE.Vector3(-9.48, 0, exitPosition.z), normal,
      `CHAMBER ${String(currentLevel + 1).padStart(2, '0')} · EXIT`, { width: 3.55, depth: 2.35, height: 3.55 });
    exitLift.targetOpen = 0;
    doorGroup = exitLift.group;
    // Paredes laterais da cabine de saída. A entrada frontal fica aberta quando a fase termina.
    addCollider(-10.65, exitPosition.z - 1.78, 2.35, 0.16, 0, 3.55);
    addCollider(-10.65, exitPosition.z + 1.78, 2.35, 0.16, 0, 3.55);
    addCollider(-11.83, exitPosition.z, 0.16, 3.55, 0, 3.55);
  }

  function updateDoorAnimation(dt) {
    // As duas folhas do elevador de saída deslizam lateralmente em vez de subir.
    updateLiftDoors(exitLift, dt);
  }

  function updateLiftSequence(dt) {
    if (!liftSequence) return;
    liftSequence.elapsed += dt;

    if (liftSequence.type === 'entry') {
      if (liftSequence.elapsed < 0.95) {
        setLiftStatus('ELEVATOR ARRIVING · PLEASE WAIT');
      } else if (liftSequence.elapsed < 2.45) {
        if (!liftSequence.openCommanded) {
          liftSequence.openCommanded = true;
          entryLift.targetOpen = 1;
          playTone(220, 0.42, 'sawtooth', 0.028);
          setLiftStatus('ENTRY DOORS OPENING');
        }
      } else {
        setLiftStatus('', false);
        liftSequence = null;
        isPlaying = true;
        updateMobileControlsVisibility();
        showToast('TEST CHAMBER ACCESS GRANTED', 2.0);
        showChapterStory(activeLevelData || LEVELS[currentLevel]);
      }
      return;
    }

    if (liftSequence.type === 'exit') {
      if (liftSequence.elapsed < 1.0) {
        setLiftStatus('ELEVATOR DOORS CLOSING');
      } else if (liftSequence.elapsed < 2.45) {
        setLiftStatus(customTestMode ? 'RETURNING FROM CUSTOM TEST' : (currentLevel < LEVELS.length - 1 ? 'TRANSIT TO THE NEXT TEST CHAMBER' : 'RETURNING TO APERTURE CENTRAL'));
        if (!liftSequence.transitTone) {
          liftSequence.transitTone = true;
          playTone(120, 0.8, 'sawtooth', 0.025);
        }
      } else if (!liftSequence.completed) {
        liftSequence.completed = true;
        setLiftStatus('ARRIVAL CONFIRMED');
        resultTimer.textContent = formatTime(elapsedLevel);
        completeTitle.textContent = customTestMode ? 'CUSTOM TEST COMPLETE.' : (currentLevel === LEVELS.length - 1 ? 'FINAL CHAMBER.' : 'TEST COMPLETE.');
        document.getElementById('next-button').innerHTML = customTestMode ? 'RETURN TO EDITOR <span>↗</span>' : (currentLevel === LEVELS.length - 1 ? 'FINISH CAMPAIGN <span>↗</span>' : 'NEXT CHAMBER <span>↗</span>');
        completeDescription.textContent = (activeLevelData || LEVELS[currentLevel]).description;
        completeScreen.classList.remove('hidden');
        playTone(560, 0.18, 'triangle', 0.05);
        sayAI('complete');
        setTimeout(() => playTone(840, 0.35, 'triangle', 0.045), 160);
        liftSequence = null;
        setTimeout(() => setLiftStatus('', false), 650);
      }
    }
  }

  // ------------------------------
  // 9. CARREGAR / REINICIAR UMA CÂMARA
  // ------------------------------
  function buildLevel(index, customLevel = null) {
    clearLevelObjects();
    setLiftStatus('', false);
    currentLevel = index;
    customTestMode = !!customLevel;
    activeLevelData = customLevel || LEVELS[index];
    currentCustomMap = customLevel ? currentCustomMap : null;
    autoSaveTimer = 0;
    const level = activeLevelData;
    exitPosition.set(-10.78, 1.57, Number.isFinite(level.exit?.z) ? level.exit.z : -7.2);
    scene.background.setHex(0x111e29);
    scene.fog.color.setHex(0x111e29);

    buildRoom(level);
    addChamberDetails(level);
    addChamberSigns(level);
    buildEntryLift(level);
    setDefaultPortals(level);
    scene.updateMatrixWorld(true);
    renderer.shadowMap.needsUpdate = true;

    level.cubes.forEach((position, cubeIndex) => makeCube(position.x, position.z, cubeIndex));
    level.plates.forEach((position, plateIndex) => makePlate(position.x, position.z, plateIndex));
    (level.launchPads || []).forEach(position => makeLaunchPad(position.x, position.z));
    (level.hazards || []).forEach(position => makeHazard(position.x, position.z));
    (level.gels || []).forEach(paint => makeGelPatch(paint.type, paint.x, paint.z, paint.width, paint.depth));
    (level.movingPlatforms || []).forEach((platform, index) => makeMovingPlatform(platform, index));
    (level.toxicPools || []).forEach(pool => makeToxicPool(pool.x, pool.z, pool.width, pool.depth));
    relay = level.relay ? makeRelay(level.relayPosition) : null;
    makeExitDoor();

    // Posição inicial dentro do elevador de entrada; velocidade e ângulo são repostos em cada câmara.
    const spawn = level.spawn || { x: 6.0, z: 0, yaw: Math.PI };
    camera.position.set(spawn.x, PLAYER.eyeHeight, spawn.z);
    yaw = spawn.yaw;
    pitch = 0;
    camera.rotation.set(pitch, yaw, 0, 'YXZ');
    verticalSpeed = 0;
    onGround = true;
    playerVelocity.set(0, 0, 0);
    horizontalVelocity.set(0, 0, 0);
    portalCooldown = 0;
    launchPadCooldown = 0;
    gelBounceCooldown = 0;
    gelFeedbackCooldown = 0;
    currentPlatform = null;
    currentGelType = null;
    elapsedLevel = 0;
    relayActivated = false;
    doorOpen = false;
    levelFinished = false;

    levelNumber.textContent = `CHAMBER ${String(index + 1).padStart(2, '0')}`;
    levelName.textContent = level.name;
    objectiveText.textContent = level.objective;
    progressFill.style.width = '0%';
    progressLabel.textContent = `0 / ${plates.length} PLATFORMS ACTIVE`;
    gelStatus.textContent = '';
    storyCard.classList.add('hidden');
    timerLabel.textContent = '00:00';
    hint.classList.remove('visible');

    loadingNote.textContent = 'WASD MOVE · MOUSE LOOK · E PICK UP / INTERACT';
  }

  // ------------------------------
  // 10. MOVIMENTO E COLISÕES
  // ------------------------------
  function isInsidePortalOpening(position) {
    // A cápsula do jogador deve caber inteira na abertura; a zona de tolerância
    // atravessa ligeiramente a parede para não bloquear o movimento antes do teleporte.
    for (const portal of [portals.blue, portals.orange]) {
      if (!portal) continue;
      const local = portal.group.worldToLocal(position.clone());
      const bottom = position.y - PLAYER.eyeHeight;
      const top = bottom + PLAYER.height;
      const openingBottom = portal.group.position.y - PORTAL.height / 2;
      const openingTop = portal.group.position.y + PORTAL.height / 2;
      const inside = Math.abs(local.x) < PORTAL.width / 2 - PLAYER.radius * 0.52
        && bottom >= openingBottom - 0.12 && top <= openingTop + 0.12
        && local.z > -0.42 && local.z < 0.82;
      if (inside) return true;
    }
    return false;
  }

  function collidesWithRoom(position, previousPosition) {
    const r = PLAYER.radius;
    const nearPortal = isInsidePortalOpening(position);

    // Limites laterais e frontal da sala. Perto de um portal, o jogador pode
    // chegar ao plano da parede para ser transportado para a outra entrada.
    if (position.x < -11.55 + r) {
      const atExit = doorOpen && Math.abs(position.z - exitPosition.z) < 1.0;
      if (!atExit && !nearPortal) return true;
    }
    if (position.x > 11.55 - r && !nearPortal) return true;
    if ((position.z < -12.55 + r || position.z > 12.55 - r) && !nearPortal) return true;

    // A galeria central é uma passagem física aberta entre as alas.
    // Para atravessar a divisória, o jogador tem de estar dentro da abertura
    // tanto no início como no fim do pequeno passo de movimento.
    const walkwayCenterLimit = WALKWAY.halfWidth - r - 0.08;
    const maxEyeHeightInWalkway = WALKWAY.clearance + PLAYER.eyeHeight - PLAYER.height;
    const inWalkway = Math.abs(position.z) < walkwayCenterLimit
      && position.y < maxEyeHeightInWalkway;
    const previousInWalkway = previousPosition
      && Math.abs(previousPosition.z) < walkwayCenterLimit
      && previousPosition.y < maxEyeHeightInWalkway;
    const insideDivider = Math.abs(position.x) < WALKWAY.wallHalfDepth + r && !nearPortal && !inWalkway;
    const crossedDivider = previousPosition
      && ((previousPosition.x < 0 && position.x >= 0) || (previousPosition.x > 0 && position.x <= 0));
    if (insideDivider || (crossedDivider && !nearPortal && !(inWalkway && previousInWalkway))) return true;

    // As folhas do elevador de saída bloqueiam o vão enquanto ainda estão fechadas.
    // Depois de abrirem, a entrada fica livre para o jogador entrar na cabine.
    if (exitLift && exitLift.openAmount < 0.9) {
      const insideClosedExitDoor = position.x < -9.28 && position.x > -10.25
        && Math.abs(position.z - exitPosition.z) < 1.36;
      if (insideClosedExitDoor) return true;
    }

    // As caixas e obstáculos têm colisão retangular simples.
    const playerBottom = position.y - PLAYER.eyeHeight;
    const playerTop = playerBottom + PLAYER.height;
    for (const box of colliders) {
      const verticallyOverlapping = playerTop > box.minY && playerBottom < box.maxY;
      const horizontallyOverlapping = position.x + r > box.minX && position.x - r < box.maxX
        && position.z + r > box.minZ && position.z - r < box.maxZ;
      if (verticallyOverlapping && horizontallyOverlapping) return true;
    }
    return false;
  }

  function resetPlayerAtSpawn(fromHazard = false) {
    const spawn = (activeLevelData || LEVELS[currentLevel]).spawn;
    if (heldCube) {
      heldCube.held = false;
      if (fromHazard) {
        const cubeSpawn = (activeLevelData || LEVELS[currentLevel]).cubes[heldCube.index];
        if (cubeSpawn) heldCube.group.position.set(cubeSpawn.x, 0.46, cubeSpawn.z);
        else heldCube.group.position.set(camera.position.x, 0.46, camera.position.z);
      } else {
        heldCube.group.position.set(camera.position.x, 0.46, camera.position.z);
      }
      heldCube = null;
    }
    currentPlatform = null;
    gelStatus.classList.remove('visible');
    camera.position.set(spawn.x, PLAYER.eyeHeight, spawn.z);
    yaw = spawn.yaw;
    pitch = 0;
    camera.rotation.set(pitch, yaw, 0, 'YXZ');
    horizontalVelocity.set(0, 0, 0);
    playerVelocity.set(0, 0, 0);
    verticalSpeed = 0;
    onGround = true;
    portalCooldown = 0.25;
    if (fromHazard) {
      showToast('HAZARD DETECTED — TEST POSITION RESET', 1.8);
      playTone(110, 0.28, 'sawtooth', 0.035);
      sayAI('hazard');
    }
  }

  function updateMovement(dt) {
    const input = new THREE.Vector3();
    gelBounceCooldown = Math.max(0, gelBounceCooldown - dt);
    gelFeedbackCooldown = Math.max(0, gelFeedbackCooldown - dt);
    const baseSpeed = (keys.ShiftLeft || keys.ShiftRight || touchActions.run) ? PLAYER.runSpeed : PLAYER.walkSpeed;
    const onSpeedGel = gelPatches.some(patch => patch.type === 'speed' && pointInsidePatch(camera.position.x, camera.position.z, patch));
    const speed = baseSpeed * (onSpeedGel ? 1.72 : 1);
    const touchingGel = gelPatches.find(patch => pointInsidePatch(camera.position.x, camera.position.z, patch));
    if (touchingGel && currentGelType !== touchingGel.type && gelFeedbackCooldown <= 0) {
      currentGelType = touchingGel.type;
      gelStatus.textContent = touchingGel.type === 'speed' ? 'PROPULSION GEL · SPEED BOOST' : 'REPULSION GEL · BOUNCE';
      gelStatus.className = `gel-status visible ${touchingGel.type}`;
      gelFeedbackCooldown = 2.4;
      sayAI(touchingGel.type === 'speed' ? 'speedGel' : 'bounceGel');
    } else if (!touchingGel && currentGelType) {
      currentGelType = null;
      gelStatus.classList.remove('visible');
    }

    // A direção do WASD agora usa exatamente o mesmo referencial da câmara Three.js:
    // o vetor para a frente é -Z local e o vetor para a direita é +X local.
    const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
    if (keys.KeyW || keys.ArrowUp) input.add(forward);
    if (keys.KeyS || keys.ArrowDown) input.sub(forward);
    if (keys.KeyD || keys.ArrowRight) input.add(right);
    if (keys.KeyA || keys.ArrowLeft) input.sub(right);
    // O joystick virtual usa X para esquerda/direita e Y para frente/trás.
    if (touchDevice && (touchMove.x || touchMove.y)) {
      input.addScaledVector(right, touchMove.x);
      input.addScaledVector(forward, -touchMove.y);
    }
    if (input.lengthSq() > 1) input.normalize();
    if (input.lengthSq() > 0) input.multiplyScalar(speed);

    // Aceleração e travagem exponenciais, independentes da taxa de fotogramas.
    const accel = input.lengthSq() > 0 ? PLAYER.acceleration : PLAYER.friction;
    const blend = 1 - Math.exp(-accel * dt);
    horizontalVelocity.lerp(input, blend);
    playerVelocity.x = horizontalVelocity.x;
    playerVelocity.z = horizontalVelocity.z;

    // Subpassos de 4 cm para não atravessar paredes, caixas ou o plano do portal.
    const frameMove = horizontalVelocity.clone().multiplyScalar(dt);
    const steps = Math.max(1, Math.ceil(frameMove.length() / 0.04));
    const stepMove = frameMove.multiplyScalar(1 / steps);
    for (let i = 0; i < steps; i++) {
      const oldPosition = camera.position.clone();
      const candidate = oldPosition.clone().add(stepMove);
      const teleported = attemptPortalTeleport(oldPosition, candidate);
      if (teleported) {
        camera.position.copy(teleported);
        showToast('PORTAL TRAVERSED', 0.75);
        sayAI('portal');
        horizontalVelocity.set(playerVelocity.x, 0, playerVelocity.z);
        break;
      }

      // Resolver cada eixo em separado permite deslizar junto às paredes sem solavancos.
      const tryX = oldPosition.clone();
      tryX.x = candidate.x;
      if (!collidesWithRoom(tryX, oldPosition)) {
        camera.position.x = tryX.x;
      } else {
        horizontalVelocity.x = 0;
        playerVelocity.x = 0;
      }

      const tryZ = camera.position.clone();
      tryZ.z = candidate.z;
      if (!collidesWithRoom(tryZ, camera.position)) {
        camera.position.z = tryZ.z;
      } else {
        horizontalVelocity.z = 0;
        playerVelocity.z = 0;
      }
    }

    if ((keys.Space || keys.KeyQ || touchActions.jump) && onGround) {
      verticalSpeed = PLAYER.jumpSpeed;
      onGround = false;
      currentPlatform = null;
      playTone(210, 0.07, 'triangle', 0.025);
    }

    const previousFootY = camera.position.y - PLAYER.eyeHeight;
    verticalSpeed -= PLAYER.gravity * dt;
    camera.position.y += verticalSpeed * dt;
    const nextFootY = camera.position.y - PLAYER.eyeHeight;
    let landedOnPlatform = null;
    if (verticalSpeed <= 0) {
      for (const platform of movingPlatforms) {
        const top = platform.group.position.y + platform.topOffset;
        const inside = Math.abs(camera.position.x - platform.group.position.x) < platform.width / 2 - PLAYER.radius * 0.35
          && Math.abs(camera.position.z - platform.group.position.z) < platform.depth / 2 - PLAYER.radius * 0.35;
        if (inside && previousFootY >= top - 0.13 && nextFootY <= top + 0.04) {
          landedOnPlatform = platform;
          camera.position.y = top + PLAYER.eyeHeight;
          verticalSpeed = 0;
          onGround = true;
          break;
        }
      }
    }
    if (landedOnPlatform) {
      currentPlatform = landedOnPlatform;
    } else if (camera.position.y <= PLAYER.eyeHeight) {
      camera.position.y = PLAYER.eyeHeight;
      verticalSpeed = 0;
      onGround = true;
      currentPlatform = null;
    } else {
      onGround = false;
      if (currentPlatform) {
        const platform = currentPlatform;
        const stillAbove = Math.abs(camera.position.x - platform.group.position.x) < platform.width / 2 - PLAYER.radius * 0.35
          && Math.abs(camera.position.z - platform.group.position.z) < platform.depth / 2 - PLAYER.radius * 0.35
          && Math.abs((camera.position.y - PLAYER.eyeHeight) - (platform.group.position.y + platform.topOffset)) < 0.22;
        if (!stillAbove) currentPlatform = null;
      }
    }
    if (camera.position.y > ROOM.height - 0.35) {
      camera.position.y = ROOM.height - 0.35;
      verticalSpeed = Math.min(0, verticalSpeed);
    }
    playerVelocity.y = verticalSpeed;

    // A tinta azul lança o jogador quando aterra; a tinta laranja multiplica a velocidade.
    if (onGround && gelBounceCooldown <= 0) {
      const bouncePatch = gelPatches.find(patch => patch.type === 'bounce' && pointInsidePatch(camera.position.x, camera.position.z, patch));
      if (bouncePatch) {
        verticalSpeed = 9.8;
        playerVelocity.y = verticalSpeed;
        onGround = false;
        currentPlatform = null;
        gelBounceCooldown = 1.05;
        playTone(310, 0.16, 'sawtooth', 0.04);
        sayAI('bounceGel');
        showToast('REPULSION GEL · BOUNCE', 1.15);
      }
    }

    // Plataformas de impulso: o jogador recebe um salto forte ao pisar no centro.
    launchPadCooldown = Math.max(0, launchPadCooldown - dt);
    if (onGround && launchPadCooldown <= 0) {
      const pad = launchPads.find(item => Math.hypot(camera.position.x - item.x, camera.position.z - item.z) < 0.78);
      if (pad) {
        verticalSpeed = 10.2;
        playerVelocity.y = verticalSpeed;
        onGround = false;
        launchPadCooldown = 1.15;
        pad.ring.material.emissiveIntensity = 2.1;
        playTone(250, 0.16, 'sawtooth', 0.04);
        setTimeout(() => { if (pad.ring?.material) pad.ring.material.emissiveIntensity = 1.15; }, 240);
        sayAI('launch');
        showToast('KINETIC BOOST', 1.0);
      }
    }

    // A grelha de segurança reinicia a posição; não elimina o cubo nem o progresso.
    if (onGround) {
      const hazard = hazards.find(item => Math.hypot(camera.position.x - item.x, camera.position.z - item.z) < item.radius);
      if (hazard) resetPlayerAtSpawn(true);
    }
    const footHeight = camera.position.y - PLAYER.eyeHeight;
    const toxicPool = toxicPools.find(pool => footHeight < 0.24
      && Math.abs(camera.position.x - pool.x) < pool.halfW
      && Math.abs(camera.position.z - pool.z) < pool.halfD);
    if (toxicPool) {
      resetPlayerAtSpawn(true);
      sayAI('toxic');
    }

    // Recuperação de segurança caso uma colisão extrema coloque o jogador fora da sala.
    if (camera.position.y < -8 || Math.abs(camera.position.x) > 40 || Math.abs(camera.position.z) > 40) {
      resetPlayerAtSpawn(false);
      showToast('POSITION RESTORED', 1.1);
    }
  }

  // ------------------------------
  // 11. CUBO NA MÃO E FÍSICA SIMPLES
  // ------------------------------
  function updateCubes(dt) {
    for (const cube of cubes) {
      if (cube.held) {
        // O cubo fica alguns centímetros abaixo do centro da câmara.
        camera.getWorldDirection(forwardVector);
        const target = camera.position.clone().addScaledVector(forwardVector, 1.55);
        target.y = Math.max(0.58, target.y - 0.12);
        cube.group.position.lerp(target, Math.min(1, dt * 14));
        cube.group.quaternion.slerp(camera.quaternion, Math.min(1, dt * 5));
        cube.verticalSpeed = 0;
      } else {
        cube.verticalSpeed -= 12 * dt;
        cube.group.position.y += cube.verticalSpeed * dt;
        if (cube.group.position.y < 0.46) {
          cube.group.position.y = 0.46;
          cube.verticalSpeed = 0;
        }
        // Uma rotação muito ligeira evita que os cubos pareçam objetos sem vida.
        cube.group.rotation.y += dt * 0.12;
      }
      // Se um cubo cair no fluido tóxico, o sistema de recuperação devolve-o ao ponto inicial.
      // Assim, uma queda acidental nunca torna a câmara impossível de concluir.
      if (!cube.held && toxicPools.some(pool => cube.group.position.y < 0.9
        && Math.abs(cube.group.position.x - pool.x) < pool.halfW
        && Math.abs(cube.group.position.z - pool.z) < pool.halfD)) {
        const safeSpawn = (activeLevelData || LEVELS[currentLevel]).cubes[cube.index];
        if (safeSpawn) cube.group.position.set(safeSpawn.x, 0.46, safeSpawn.z);
        cube.verticalSpeed = 0;
        showToast('CUBE RECOVERY SYSTEM ACTIVATED', 1.1);
      }
    }
  }

  function findTarget() {
    raycaster.setFromCamera(screenCenter, camera);
    const candidates = interactables.filter(object => object.visible !== false);
    const hits = raycaster.intersectObjects(candidates, false);
    if (hits.length && hits[0].distance <= 3.8) return hits[0].object;

    // Ajuda contextual: perto de um objeto, E escolhe-o mesmo sem apontar ao milímetro.
    // Evita que o primeiro cubo pareça impossível de apanhar a quem está a aprender.
    const origin = camera.position.clone();
    camera.getWorldDirection(forwardVector);
    let best = null;
    let bestDistance = 3.0;
    for (const object of candidates) {
      const item = object.userData.item;
      const center = item?.group ? item.group.position.clone() : object.getWorldPosition(new THREE.Vector3());
      if (object.userData.kind === 'cube') center.y += 0.35;
      const offset = center.sub(origin);
      const distance = offset.length();
      if (distance > bestDistance || distance < 0.01) continue;
      const facing = offset.normalize().dot(forwardVector);
      if (facing > 0.15) { best = object; bestDistance = distance; }
    }
    return best;
  }

  function updateInteractionHint() {
    if (heldCube) {
      hint.textContent = 'E  ·  DROP CUBE';
      hint.classList.add('visible');
      return;
    }
    const target = findTarget();
    if (!target) {
      hint.classList.remove('visible');
      return;
    }
    if (target.userData.kind === 'cube') {
      hint.textContent = 'E  ·  PICK UP CUBE';
      hint.classList.add('visible');
    } else if (target.userData.kind === 'relay') {
      hint.textContent = target.userData.item.active ? 'POWER RELAY ACTIVE' : 'E  ·  ACTIVATE RELAY';
      hint.classList.add('visible');
    } else {
      hint.classList.remove('visible');
    }
  }

  function interact() {
    if (!isPlaying) return;
    if (heldCube) {
      heldCube.held = false;
      heldCube.group.position.y = Math.max(0.46, heldCube.group.position.y);
      heldCube = null;
      playTone(250, 0.09, 'triangle', 0.035);
      showToast('CUBO LARGADO', 0.9);
      return;
    }

    const target = findTarget();
    if (!target) return;
    if (target.userData.kind === 'cube') {
      const item = target.userData.item;
      item.held = true;
      heldCube = item;
      playTone(460, 0.11, 'sine', 0.04);
      showToast('CUBO RECOLHIDO', 0.9);
      sayAI('cube');
    } else if (target.userData.kind === 'relay') {
      const item = target.userData.item;
      if (!item.active) {
        item.active = true;
        item.button.material.color.setHex(0x80efc3);
        item.button.material.emissive.setHex(0x23a77b);
        item.button.material.emissiveIntensity = 1.3;
        playTone(680, 0.18, 'triangle', 0.05);
        showToast('RELÉ DE ENERGIA ATIVADO', 1.4);
        sayAI('relay');
      } else {
        showToast('RELÉ JÁ ATIVO', 0.8);
      }
    }
  }

  // ------------------------------
  // 12. SAÍDA, PAUSA E PROGRESSÃO
  // ------------------------------
  function checkExit() {
    if (!doorOpen || levelFinished) return;
    const liftIsOpen = exitLift && exitLift.openAmount > 0.88;
    const insideElevator = camera.position.x < -10.55 && Math.abs(camera.position.z - exitPosition.z) < 1.05;
    if (liftIsOpen && insideElevator) finishLevel();
  }

  function finishLevel() {
    if (liftSequence) return;
    levelFinished = true;
    isPlaying = false;
    updateMobileControlsVisibility();
    if (!customTestMode) {
      totalElapsed += elapsedLevel;
      completedLevels.add(currentLevel);
      unlockedLevel = Math.min(LEVELS.length - 1, Math.max(unlockedLevel, currentLevel + 1));
      saveAutoCheckpoint(Math.min(currentLevel + 1, LEVELS.length - 1));
      if (currentLevel === LEVELS.length - 1 && saveData) saveData.campaignComplete = true;
      writeSaveData();
    }
    if (document.pointerLockElement) document.exitPointerLock();

    // O jogador já entrou na cabine: as portas fecham e o elevador espera
    // antes de apresentar a conclusão e permitir carregar a próxima câmara.
    if (exitLift) exitLift.targetOpen = 0;
    liftSequence = { type: 'exit', elapsed: 0, transitTone: false, completed: false };
    setLiftStatus('ELEVATOR DOORS CLOSING');
    playTone(280, 0.25, 'sawtooth', 0.03);
    sayAI('liftDepart');
  }

  function startGame(skipEntryLift = false) {
    if (!hasStarted) {
      hasStarted = true;
      totalRunStart = performance.now();
      totalElapsed = 0;
    }
    startScreen.classList.add('hidden');
    chamberScreen.classList.add('hidden');
    saveScreen.classList.add('hidden');
    pauseScreen.classList.add('hidden');
    completeScreen.classList.add('hidden');
    endingScreen.classList.add('hidden');
    editorScreen.classList.add('hidden');
    hud.classList.remove('hidden');
    updateMobileControlsVisibility();
    if (skipEntryLift) {
      if (entryLift) { entryLift.openAmount = 1; entryLift.targetOpen = 1; }
      liftSequence = null;
      isPlaying = true;
      updateMobileControlsVisibility();
      setLiftStatus('', false);
      if (!touchDevice) renderer.domElement.requestPointerLock?.();
      saveAutoCheckpoint();
      return;
    }
    isPlaying = false; // O controlo só regressa quando as portas do elevador abrirem.
    if (entryLift) {
      entryLift.openAmount = 0;
      entryLift.targetOpen = 0;
    }
    liftSequence = { type: 'entry', elapsed: 0, openCommanded: false };
    setLiftStatus('ELEVATOR ARRIVING · PLEASE WAIT');
    if (!touchDevice) renderer.domElement.requestPointerLock?.();
    playTone(150, 0.28, 'sine', 0.025);
    saveAutoCheckpoint();
  }

  function pauseGame() {
    if (!isPlaying || levelFinished) return;
    isPlaying = false;
    updateMobileControlsVisibility();
    pauseScreen.classList.remove('hidden');
    document.getElementById('quick-save-button').classList.toggle('hidden', customTestMode);
    document.getElementById('manage-saves-button').classList.toggle('hidden', customTestMode);
    document.getElementById('return-editor-button').classList.toggle('hidden', !customTestMode);
    saveAutoCheckpoint();
    if (document.pointerLockElement) document.exitPointerLock();
  }

  function resumeGame() {
    pauseScreen.classList.add('hidden');
    isPlaying = true;
    updateMobileControlsVisibility();
    if (!touchDevice) renderer.domElement.requestPointerLock?.();
  }

  function restartCurrentLevel() {
    pauseScreen.classList.add('hidden');
    completeScreen.classList.add('hidden');
    if (customTestMode && currentCustomMap) buildLevel(0, editorMapToLevel(currentCustomMap));
    else buildLevel(currentLevel);
    startGame();
    showToast('CÂMARA REINICIADA · ELEVADOR A ABRIR', 1.6);
  }

  function returnFromCustomTest() {
    if (!customTestMode) return;
    customTestMode = false;
    isPlaying = false;
    levelFinished = false;
    pauseScreen.classList.add('hidden');
    completeScreen.classList.add('hidden');
    hud.classList.add('hidden');
    updateMobileControlsVisibility();
    if (document.pointerLockElement) document.exitPointerLock();
    editorScreen.classList.remove('hidden');
    renderEditorMap();
    editorMessage.textContent = 'Voltaste ao editor. As alterações que guardaste continuam disponíveis.';
  }

  function goToNextLevel() {
    completeScreen.classList.add('hidden');
    if (customTestMode) {
      returnFromCustomTest();
      return;
    }
    if (currentLevel + 1 < LEVELS.length) {
      buildLevel(currentLevel + 1);
      startGame();
      showToast('NEW TEST CHAMBER LOADED', 1.3);
      sayAI('next');
      saveAutoCheckpoint();
    } else {
      totalTimer.textContent = formatTime(totalElapsed);
      if (saveData) saveData.campaignComplete = true;
      writeSaveData();
      endingScreen.classList.remove('hidden');
      hud.classList.add('hidden');
    }
  }

  // ------------------------------
  // 12A. EDITOR DE FASES E PARTILHA DE MAPAS
  // ------------------------------
  const EDITOR_COLS = 22;
  const EDITOR_ROWS = 24;
  const EDITOR_STORAGE_KEY = 'portalLabCustomChambers_v1';
  const EDITOR_KINDS = new Set(['wall', 'panel', 'cube', 'plate', 'relay', 'speed', 'bounce', 'moving', 'toxic', 'launch', 'hazard']);

  function copyData(value) { return JSON.parse(JSON.stringify(value)); }
  function makeEditorId() { return `obj_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`; }

  function makeBlankEditorMap() {
    return {
      format: 'PORTAL_LAB_CHAMBER', version: 1, id: '',
      name: 'My Aperture Test', author: 'Test Designer',
      objective: 'Leva o cubo até à placa e encontra o elevador de saída.',
      spawn: { x: 18, y: 23 }, exit: { x: 0, y: 7 },
      objects: [
        { id: makeEditorId(), kind: 'cube', x: 16, y: 18 },
        { id: makeEditorId(), kind: 'plate', x: 5, y: 8 },
        { id: makeEditorId(), kind: 'relay', x: 3, y: 5 }
      ]
    };
  }

  function readEditorMaps() {
    try {
      const parsed = JSON.parse(localStorage.getItem(EDITOR_STORAGE_KEY) || '[]');
      return Array.isArray(parsed) ? parsed.filter(map => map && map.format === 'PORTAL_LAB_CHAMBER' && Array.isArray(map.objects)) : [];
    } catch (error) { return []; }
  }

  function persistEditorMaps() {
    try {
      localStorage.setItem(EDITOR_STORAGE_KEY, JSON.stringify(editorSavedMaps));
      return true;
    } catch (error) { return false; }
  }

  function worldFromEditorCell(cell) {
    return { x: -10.5 + cell.x, z: -11.5 + cell.y };
  }

  function editorCellAt(event) {
    const rect = editorCanvas.getBoundingClientRect();
    const x = Math.floor((event.clientX - rect.left) / rect.width * EDITOR_COLS);
    const y = Math.floor((event.clientY - rect.top) / rect.height * EDITOR_ROWS);
    if (x < 0 || x >= EDITOR_COLS || y < 0 || y >= EDITOR_ROWS) return null;
    return { x, y };
  }

  function setEditorMessage(message, isError = false) {
    editorMessage.textContent = message;
    editorMessage.classList.toggle('error', isError);
  }

  function pushEditorHistory() {
    editorHistory.push(copyData(editorMap));
    if (editorHistory.length > 40) editorHistory.shift();
  }

  function renderEditorMap() {
    if (!editorCtx || !editorMap) return;
    const ctx = editorCtx;
    const w = editorCanvas.width;
    const h = editorCanvas.height;
    const cw = w / EDITOR_COLS;
    const ch = h / EDITOR_ROWS;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#101e28';
    ctx.fillRect(0, 0, w, h);

    // Cada quadrado representa um metro aproximado no plano da câmara.
    for (let row = 0; row < EDITOR_ROWS; row++) {
      for (let col = 0; col < EDITOR_COLS; col++) {
        ctx.fillStyle = (row + col) % 2 ? '#1b2b35' : '#1e303a';
        ctx.fillRect(col * cw, row * ch, cw, ch);
      }
    }

    // Parede central da instalação, desenhada com o vão livre da galeria.
    const dividerX = 10.5 * cw;
    ctx.fillStyle = '#52636d';
    ctx.fillRect(dividerX - 3, 0, 6, 8.2 * ch);
    ctx.fillRect(dividerX - 3, 14.8 * ch, 6, h - 14.8 * ch);
    ctx.fillStyle = 'rgba(55,190,225,.18)';
    ctx.fillRect(dividerX - 2, 8.2 * ch, 4, 6.6 * ch);
    ctx.strokeStyle = 'rgba(102,218,245,.55)';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(dividerX, 8.3 * ch); ctx.lineTo(dividerX, 14.7 * ch); ctx.stroke();

    // Moldura do perímetro da sala.
    ctx.strokeStyle = 'rgba(142,183,198,.55)'; ctx.lineWidth = 3;
    ctx.strokeRect(1.5, 1.5, w - 3, h - 3);

    const drawIcon = (object) => {
      const x = (object.x + 0.5) * cw;
      const y = (object.y + 0.5) * ch;
      const size = Math.min(cw, ch) * 0.72;
      ctx.save();
      ctx.translate(x, y);
      if (object.kind === 'wall') {
        ctx.fillStyle = '#8999a1'; ctx.fillRect(-size * .42, -size * .42, size * .84, size * .84);
        ctx.strokeStyle = '#d1dce0'; ctx.lineWidth = 1.5; ctx.strokeRect(-size * .42, -size * .42, size * .84, size * .84);
        ctx.beginPath(); ctx.moveTo(-size*.3,-size*.22); ctx.lineTo(size*.3,-size*.22); ctx.moveTo(-size*.3,size*.22); ctx.lineTo(size*.3,size*.22); ctx.stroke();
      } else if (object.kind === 'panel') {
        ctx.fillStyle = '#738d98'; ctx.fillRect(-size*.46,-size*.18,size*.92,size*.36);
        ctx.strokeStyle = '#73dafa'; ctx.lineWidth=2; ctx.strokeRect(-size*.46,-size*.18,size*.92,size*.36);
        ctx.fillStyle='#eafaff';ctx.font=`bold ${size*.28}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('PORTAL',0,0);
      } else if (object.kind === 'cube') {
        ctx.fillStyle = '#dce7e9'; ctx.fillRect(-size*.33,-size*.33,size*.66,size*.66);
        ctx.strokeStyle = '#58c8ec'; ctx.lineWidth = 2; ctx.strokeRect(-size*.33,-size*.33,size*.66,size*.66);
        ctx.beginPath(); ctx.arc(0,0,size*.14,0,Math.PI*2); ctx.stroke();
      } else if (object.kind === 'plate') {
        ctx.fillStyle = '#243943'; ctx.beginPath(); ctx.arc(0,0,size*.45,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#7bdcc0'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0,0,size*.32,0,Math.PI*2); ctx.stroke();
      } else if (object.kind === 'relay') {
        ctx.fillStyle = '#b6d5df'; ctx.fillRect(-size*.32,-size*.4,size*.64,size*.8);
        ctx.fillStyle = '#54cbea'; ctx.font = `bold ${size*.7}px Arial`; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText('ϟ',0,1);
      } else if (object.kind === 'speed' || object.kind === 'bounce') {
        ctx.fillStyle = object.kind === 'speed' ? '#ed913e' : '#37bdec';
        ctx.globalAlpha = .86; ctx.beginPath(); ctx.ellipse(0,0,size*.5,size*.39,-.2,0,Math.PI*2); ctx.fill();
        ctx.globalAlpha = 1; ctx.strokeStyle='rgba(255,255,255,.72)'; ctx.lineWidth=1.3; ctx.beginPath();ctx.moveTo(-size*.25,-size*.1);ctx.lineTo(size*.22,size*.12);ctx.stroke();
      } else if (object.kind === 'moving') {
        ctx.fillStyle = '#62d4ef'; ctx.fillRect(-size*.48,-size*.29,size*.96,size*.58);
        ctx.strokeStyle='#d6f8ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-size*.28,0);ctx.lineTo(size*.28,0);ctx.moveTo(size*.16,-size*.12);ctx.lineTo(size*.28,0);ctx.lineTo(size*.16,size*.12);ctx.stroke();
      } else if (object.kind === 'toxic') {
        ctx.fillStyle = 'rgba(65,205,128,.7)'; ctx.fillRect(-size*.5,-size*.45,size,size*.9);
        ctx.strokeStyle='#b1ffd0';ctx.lineWidth=1.5;ctx.strokeRect(-size*.5,-size*.45,size,size*.9);
        ctx.fillStyle='#efffe8';ctx.font=`bold ${size*.5}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('!',0,1);
      } else if (object.kind === 'launch') {
        ctx.fillStyle='#1c3947';ctx.beginPath();ctx.arc(0,0,size*.44,0,Math.PI*2);ctx.fill();
        ctx.strokeStyle='#54d6f4';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,size*.23);ctx.lineTo(0,-size*.25);ctx.lineTo(-size*.13,-size*.08);ctx.moveTo(0,-size*.25);ctx.lineTo(size*.13,-size*.08);ctx.stroke();
      } else if (object.kind === 'hazard') {
        ctx.fillStyle='#7c2628';ctx.fillRect(-size*.43,-size*.43,size*.86,size*.86);
        ctx.strokeStyle='#ff665b';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-size*.3,-size*.3);ctx.lineTo(size*.3,size*.3);ctx.moveTo(size*.3,-size*.3);ctx.lineTo(-size*.3,size*.3);ctx.stroke();
      }
      if (editorSelectedId === object.id) {
        ctx.strokeStyle = '#fff6a5'; ctx.lineWidth = 2.5; ctx.setLineDash([4, 2]);
        ctx.strokeRect(-cw*.46,-ch*.46,cw*.92,ch*.92);
      }
      ctx.restore();
    };

    editorMap.objects.forEach(drawIcon);

    const drawLift = (cell, label, color, id) => {
      const x = (cell.x + .5) * cw, y = (cell.y + .5) * ch;
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = color; ctx.fillRect(-cw*.42,-ch*.38,cw*.84,ch*.76);
      ctx.strokeStyle = '#f1f7f8'; ctx.lineWidth = 1.5; ctx.strokeRect(-cw*.42,-ch*.38,cw*.84,ch*.76);
      ctx.strokeStyle = 'rgba(7,20,27,.75)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0,-ch*.27);ctx.lineTo(0,ch*.27);ctx.stroke();
      ctx.fillStyle='#071923';ctx.font='900 8px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,0,0);
      if (editorSelectedId === id) { ctx.strokeStyle='#fff6a5';ctx.lineWidth=2.5;ctx.setLineDash([4,2]);ctx.strokeRect(-cw*.47,-ch*.44,cw*.94,ch*.88); }
      ctx.restore();
    };
    drawLift(editorMap.spawn, 'IN', '#43b990', 'spawn');
    drawLift(editorMap.exit, 'OUT', '#de8950', 'exit');

    // Pequena bússola e escala.
    ctx.fillStyle='rgba(235,247,250,.62)';ctx.font='bold 10px Arial';ctx.textAlign='left';ctx.fillText('N',8,14);
    ctx.fillRect(w-42,h-8,28,2);
  }

  function refreshEditorSelection() {
    if (!editorSelection) return;
    if (!editorSelectedId) {
      editorSelection.textContent = 'Seleciona uma célula ocupada para inspecionar o objeto. Podes apagar ou substituir objetos usando as ferramentas.';
      return;
    }
    if (editorSelectedId === 'spawn') {
      editorSelection.textContent = `ELEVADOR DE ENTRADA · coluna ${editorMap.spawn.x + 1}, linha ${editorMap.spawn.y + 1}. Só pode ser colocado junto às extremidades norte ou sul.`;
      return;
    }
    if (editorSelectedId === 'exit') {
      editorSelection.textContent = `ELEVADOR DE SAÍDA · coluna ${editorMap.exit.x + 1}, linha ${editorMap.exit.y + 1}. A saída fica na parede esquerda.`;
      return;
    }
    const object = editorMap.objects.find(item => item.id === editorSelectedId);
    if (!object) { editorSelectedId = null; editorSelection.textContent = 'Nenhum objeto selecionado.'; return; }
    const names = { wall:'Parede / bloco sólido', panel:'Painel vertical que aceita portais', cube:'Cubo de armazenamento', plate:'Placa de pressão', relay:'Relé de energia', speed:'Tinta de velocidade', bounce:'Tinta de salto', moving:'Plataforma móvel', toxic:'Água tóxica', launch:'Plataforma de impulso', hazard:'Grelha perigosa' };
    editorSelection.textContent = `${names[object.kind] || object.kind} · coluna ${object.x + 1}, linha ${object.y + 1}. ${object.kind === 'moving' ? 'A plataforma desloca-se automaticamente na horizontal.' : object.kind === 'toxic' ? 'Tocar na água reinicia o jogador.' : object.kind === 'wall' ? 'Bloco sólido com 3,2 metros de altura.' : 'Objeto colocado na grelha.'}`;
  }

  function updateEditorMetaFromInputs() {
    if (!editorMap) return;
    editorMap.name = editorName.value.trim().slice(0, 42) || 'Untitled Test';
    editorMap.author = editorAuthor.value.trim().slice(0, 28) || 'Unknown';
    editorMap.objective = editorObjective.value.trim().slice(0, 120) || 'Resolve o teste e encontra a saída.';
  }

  function selectEditorTool(tool) {
    editorTool = tool;
    document.querySelectorAll('.editor-tool').forEach(button => button.classList.toggle('active', button.dataset.tool === tool));
    editorCanvas.style.cursor = tool === 'select' ? 'default' : tool === 'erase' ? 'not-allowed' : 'crosshair';
  }

  function findEditorCellItem(cell) {
    const obj = editorMap.objects.find(item => item.x === cell.x && item.y === cell.y);
    if (obj) return obj.id;
    if (editorMap.spawn.x === cell.x && editorMap.spawn.y === cell.y) return 'spawn';
    if (editorMap.exit.x === cell.x && editorMap.exit.y === cell.y) return 'exit';
    return null;
  }

  function placeEditorItem(cell) {
    if (!cell) return;
    const currentId = findEditorCellItem(cell);
    if (editorTool === 'select') {
      editorSelectedId = currentId;
      refreshEditorSelection(); renderEditorMap();
      const world = worldFromEditorCell(cell);
      document.getElementById('editor-coordinates').textContent = `X: ${world.x.toFixed(1)} · Z: ${world.z.toFixed(1)}`;
      return;
    }
    if (!['erase', 'spawn', 'exit'].includes(editorTool)
      && ((editorMap.spawn.x === cell.x && editorMap.spawn.y === cell.y)
        || (editorMap.exit.x === cell.x && editorMap.exit.y === cell.y))) {
      setEditorMessage('Não podes colocar objetos dentro dos elevadores.', true);
      return;
    }
    pushEditorHistory();
    if (editorTool === 'erase') {
      editorMap.objects = editorMap.objects.filter(item => !(item.x === cell.x && item.y === cell.y));
      if (editorMap.spawn.x === cell.x && editorMap.spawn.y === cell.y) editorMap.spawn = { x: 18, y: 23 };
      if (editorMap.exit.x === cell.x && editorMap.exit.y === cell.y) editorMap.exit = { x: 0, y: 7 };
      editorSelectedId = null;
    } else if (editorTool === 'spawn') {
      // Elevador de entrada fixo à extremidade norte/sul para alinhar a cabine 3D.
      const y = cell.y < EDITOR_ROWS / 2 ? 0 : EDITOR_ROWS - 1;
      editorMap.spawn = { x: Math.max(3, Math.min(EDITOR_COLS - 4, cell.x)), y };
      editorSelectedId = 'spawn';
    } else if (editorTool === 'exit') {
      // O elevador de saída está embutido na parede esquerda da sala.
      editorMap.exit = { x: 0, y: Math.max(3, Math.min(EDITOR_ROWS - 4, cell.y)) };
      editorSelectedId = 'exit';
    } else {
      if (editorTool === 'relay' && editorMap.objects.some(item => item.kind === 'relay' && !(item.x === cell.x && item.y === cell.y))) {
        editorMap.objects = editorMap.objects.filter(item => item.kind !== 'relay');
      }
      editorMap.objects = editorMap.objects.filter(item => !(item.x === cell.x && item.y === cell.y));
      const object = { id: makeEditorId(), kind: editorTool, x: cell.x, y: cell.y };
      editorMap.objects.push(object);
      editorSelectedId = object.id;
    }
    updateEditorMetaFromInputs();
    refreshEditorSelection(); renderEditorMap();
  }

  function undoEditorAction() {
    const previous = editorHistory.pop();
    if (!previous) { setEditorMessage('Não existem mais ações para desfazer.'); return; }
    editorMap = previous;
    editorSelectedId = null;
    syncEditorInputs(); renderEditorMap(); refreshEditorSelection();
    setEditorMessage('Última ação desfeita.');
  }

  function syncEditorInputs() {
    editorName.value = editorMap.name || '';
    editorAuthor.value = editorMap.author || '';
    editorObjective.value = editorMap.objective || '';
  }

  function clearEditorMap() {
    if (!window.confirm('Apagar todos os objetos desta fase?')) return;
    pushEditorHistory();
    editorMap.objects = [];
    editorSelectedId = null;
    renderEditorMap(); refreshEditorSelection();
    setEditorMessage('Mapa limpo. Os elevadores de entrada e saída foram mantidos.');
  }

  function renderEditorSavedList() {
    editorSavedSelect.replaceChildren();
    const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Escolhe uma fase guardada…';
    editorSavedSelect.appendChild(placeholder);
    editorSavedMaps.forEach((map, index) => {
      const option = document.createElement('option'); option.value = String(index); option.textContent = `${map.name || 'Untitled'} — ${map.author || 'Unknown'}`;
      editorSavedSelect.appendChild(option);
    });
  }

  function saveEditorMapLocally() {
    updateEditorMetaFromInputs();
    const map = copyData(editorMap);
    map.id = map.id || `local_${Date.now().toString(36)}`;
    const index = editorSavedMaps.findIndex(item => item.id === map.id);
    if (index >= 0) editorSavedMaps[index] = map; else editorSavedMaps.push(map);
    editorMap.id = map.id;
    const ok = persistEditorMaps();
    renderEditorSavedList();
    if (ok) setEditorMessage(`Fase guardada em MY CHAMBERS: ${map.name}.` , false);
    else setEditorMessage('Não foi possível guardar. O armazenamento do navegador pode estar cheio ou bloqueado.', true);
  }

  function loadSelectedEditorMap() {
    const index = Number(editorSavedSelect.value);
    if (!Number.isInteger(index) || !editorSavedMaps[index]) { setEditorMessage('Escolhe uma fase guardada primeiro.', true); return; }
    editorMap = sanitizeEditorMap(editorSavedMaps[index]);
    editorHistory = []; editorSelectedId = null;
    syncEditorInputs(); renderEditorMap(); refreshEditorSelection();
    setEditorMessage(`Fase carregada: ${editorMap.name}.`);
  }

  function deleteSelectedEditorMap() {
    const index = Number(editorSavedSelect.value);
    if (!Number.isInteger(index) || !editorSavedMaps[index]) { setEditorMessage('Escolhe uma fase guardada primeiro.', true); return; }
    const name = editorSavedMaps[index].name || 'Untitled';
    editorSavedMaps.splice(index, 1); persistEditorMaps(); renderEditorSavedList();
    setEditorMessage(`Fase ${name} apagada das tuas fases guardadas.`);
  }

  function sanitizeEditorMap(raw) {
    const source = raw && raw.map ? raw.map : raw;
    if (!source || source.format !== 'PORTAL_LAB_CHAMBER' || source.version !== 1 || !Array.isArray(source.objects)) {
      throw new Error('O ficheiro não é um mapa Portal Lab válido.');
    }
    const inBounds = cell => cell && Number.isInteger(cell.x) && Number.isInteger(cell.y)
      && cell.x >= 0 && cell.x < EDITOR_COLS && cell.y >= 0 && cell.y < EDITOR_ROWS;
    if (!inBounds(source.spawn) || !inBounds(source.exit)) throw new Error('O ficheiro tem uma entrada ou saída fora da grelha.');
    if (source.objects.length > 120) throw new Error('O mapa excede o limite de 120 objetos.');
    const occupiedCells = new Set();
    const objects = source.objects.map(item => {
      if (!item || !EDITOR_KINDS.has(item.kind) || !inBounds(item)) throw new Error('O mapa contém um objeto inválido ou fora da grelha.');
      const cellKey = `${item.x},${item.y}`;
      if (occupiedCells.has(cellKey)) throw new Error('O mapa tem mais do que um objeto na mesma célula.');
      occupiedCells.add(cellKey);
      if ((item.x === source.spawn.x && (item.y === 0 || item.y === EDITOR_ROWS - 1))
        || (item.x === source.exit.x && item.y === source.exit.y)) {
        throw new Error('O mapa coloca um objeto dentro de um elevador.');
      }
      return { id: typeof item.id === 'string' ? item.id.slice(0, 80) : makeEditorId(), kind: item.kind, x: item.x, y: item.y, rotation: item.kind === 'panel' ? ((Number(item.rotation) || 0) % 4 + 4) % 4 : 0 };
    });
    return {
      format: 'PORTAL_LAB_CHAMBER', version: 1,
      id: typeof source.id === 'string' ? source.id.slice(0, 80) : '',
      name: String(source.name || 'Imported Test').slice(0, 42),
      author: String(source.author || 'Unknown').slice(0, 28),
      objective: String(source.objective || 'Resolve o teste e encontra a saída.').slice(0, 120),
      spawn: { x: Math.max(3, Math.min(EDITOR_COLS - 4, source.spawn.x)), y: source.spawn.y < EDITOR_ROWS / 2 ? 0 : EDITOR_ROWS - 1 },
      exit: { x: 0, y: Math.max(3, Math.min(EDITOR_ROWS - 4, source.exit.y)) },
      objects
    };
  }

  function editorMapToLevel(map) {
    const at = (item) => worldFromEditorCell(item);
    const objects = map.objects;
    const coords = kind => objects.filter(item => item.kind === kind).map(at);
    const relayObject = objects.find(item => item.kind === 'relay');
    const relayPosition = relayObject ? at(relayObject) : null;
    const spawnWorld = at(map.spawn);
    const spawnZ = map.spawn.y < EDITOR_ROWS / 2 ? -10.45 : 10.45;
    return {
      name: map.name,
      objective: map.objective,
      storyTitle: 'CUSTOM TEST',
      storyIntro: `Welcome, ${map.author}. Your custom test chamber is now active. The laboratory hopes you have considered all possible outcomes.`,
      description: `Custom test by ${map.author}. Chamber: ${map.name}.`,
      spawn: { x: spawnWorld.x, z: spawnZ, yaw: spawnZ < 0 ? Math.PI : 0 },
      exit: { z: at(map.exit).z },
      cubes: coords('cube'),
      plates: coords('plate'),
      relay: !!relayObject,
      relayPosition,
      obstacles: objects.filter(item => item.kind === 'wall').map(item => ({ ...at(item), w: 0.88, d: 0.88, h: 3.2 })),
      portalPanels: objects.filter(item => item.kind === 'panel').map(item => ({ ...at(item), rotation: item.rotation || 0 })),
      launchPads: coords('launch'),
      hazards: coords('hazard'),
      gels: objects.filter(item => item.kind === 'speed' || item.kind === 'bounce').map(item => ({ ...at(item), type: item.kind, width: 3.1, depth: 2.25 })),
      movingPlatforms: objects.filter(item => item.kind === 'moving').map(item => ({ ...at(item), width: 3.1, depth: 2.3, axis: 'x', travel: 2.1, speed: 0.62, phase: 0, y: 0.58 })),
      toxicPools: objects.filter(item => item.kind === 'toxic').map(item => ({ ...at(item), width: 3.4, depth: 3.0 })),
      accent: 0x35b8df
    };
  }

  function validateEditorMap(map) {
    const errors = [];
    const walls = new Set();
    // Os painéis para portais têm cerca de 3,2 m de largura; a grelha é
    // aproximada em metros, por isso também bloqueamos as células adjacentes
    // ao longo da largura real do painel na validação do percurso.
    for (const item of map.objects) {
      if (item.kind === 'wall') walls.add(`${item.x},${item.y}`);
      if (item.kind === 'panel') {
        walls.add(`${item.x},${item.y}`);
        if ((item.rotation || 0) % 2 === 0) {
          if (item.x > 0) walls.add(`${item.x - 1},${item.y}`);
          if (item.x < EDITOR_COLS - 1) walls.add(`${item.x + 1},${item.y}`);
        } else {
          if (item.y > 0) walls.add(`${item.x},${item.y - 1}`);
          if (item.y < EDITOR_ROWS - 1) walls.add(`${item.x},${item.y + 1}`);
        }
      }
    }
    const plateCount = map.objects.filter(item => item.kind === 'plate').length;
    const cubeCount = map.objects.filter(item => item.kind === 'cube').length;
    const relayCount = map.objects.filter(item => item.kind === 'relay').length;
    if (plateCount > cubeCount) errors.push(`Existem ${plateCount} placas mas apenas ${cubeCount} cubos. Cada placa precisa de um cubo.`);
    if (relayCount > 1) errors.push('O jogo suporta um relé por fase.');
    if (map.objects.some(item => (item.kind === 'wall' || item.kind === 'panel') && Math.abs(item.x - map.spawn.x) <= 1 && Math.abs(item.y - map.spawn.y) <= 1)) errors.push('Há uma parede demasiado perto do elevador de entrada.');
    if (map.objects.some(item => item.x <= 1 && Math.abs(item.y - map.exit.y) <= 1)) errors.push('Há um objeto a bloquear o elevador de saída.');
    if (map.objects.length > 120) errors.push('O limite é de 120 objetos por fase.');

    // Pesquisa de caminho simples: impede paredes colocadas em linha de fechar toda a rota.
    const start = { x: map.spawn.x, y: map.spawn.y };
    const end = { x: map.exit.x, y: map.exit.y };
    const queue = [start];
    const visited = new Set([`${start.x},${start.y}`]);
    let reachable = false;
    while (queue.length) {
      const cell = queue.shift();
      if (cell.x === end.x && cell.y === end.y) { reachable = true; break; }
      for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
        const nx = cell.x + dx, ny = cell.y + dy;
        if (nx < 0 || nx >= EDITOR_COLS || ny < 0 || ny >= EDITOR_ROWS) continue;
        const key = `${nx},${ny}`;
        if (visited.has(key) || walls.has(key)) continue;
        // A divisória central só permite atravessar pelo corredor no meio da câmara.
        const crossesDivider = (cell.x === 10 && nx === 11) || (cell.x === 11 && nx === 10);
        if (crossesDivider && (ny < 9 || ny > 14)) continue;
        visited.add(key); queue.push({ x: nx, y: ny });
      }
    }
    if (!reachable) errors.push('As paredes bloqueiam o caminho entre a entrada e a saída. Abre uma passagem.');
    if (plateCount === 0 && relayCount === 0) errors.push('Aviso: sem placas nem relé, a porta de saída abre automaticamente.');
    if (map.objects.some(item => item.kind === 'toxic' && (Math.abs(item.x - map.spawn.x) < 2 && (item.y < 3 || item.y > 20)))) errors.push('A água tóxica está demasiado perto da entrada.');
    return errors;
  }

  function testEditorMap() {
    updateEditorMetaFromInputs();
    const errors = validateEditorMap(editorMap);
    const blockingErrors = errors.filter(message => !message.startsWith('Aviso:'));
    if (blockingErrors.length) {
      setEditorMessage(`Não é possível testar: ${blockingErrors.join(' ')}`, true);
      return;
    }
    const warning = errors.find(message => message.startsWith('Aviso:'));
    if (warning && !window.confirm(`${warning}\n\nQueres testar mesmo assim?`)) return;
    currentCustomMap = copyData(editorMap);
    const customLevel = editorMapToLevel(currentCustomMap);
    buildLevel(0, customLevel);
    hasStarted = false;
    totalElapsed = 0;
    editorScreen.classList.add('hidden');
    startGame();
    sayAI('next');
  }

  function downloadEditorMap() {
    updateEditorMetaFromInputs();
    const exported = copyData(editorMap);
    exported.format = 'PORTAL_LAB_CHAMBER'; exported.version = 1;
    const json = JSON.stringify(exported, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const safeName = (editorMap.name || 'portal-lab-chamber').toLowerCase().replace(/[^a-z0-9-_]+/g, '-').replace(/^-|-$/g, '') || 'portal-lab-chamber';
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `${safeName}.portalmap`;
    document.body.appendChild(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    setEditorMessage(`Ficheiro ${safeName}.portalmap exportado. Envia-o a outra pessoa para partilhar a fase.`);
    return new File([blob], `${safeName}.portalmap`, { type: 'application/json' });
  }

  async function shareEditorMap() {
    let file;
    try { file = downloadEditorMap(); } catch (error) { setEditorMessage('Não foi possível exportar esta fase.', true); return; }
    if (navigator.share && file && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ title: editorMap.name, text: `Experimenta a minha fase Portal Lab: ${editorMap.name}`, files: [file] });
        setEditorMessage('Menu de partilha aberto.');
      } catch (error) {
        if (error.name !== 'AbortError') setEditorMessage('O ficheiro foi exportado. Podes anexá-lo manualmente na aplicação que preferires.');
      }
    } else {
      setEditorMessage('O ficheiro foi descarregado. Anexa o .portalmap numa mensagem, email ou serviço de partilha.');
    }
  }

  async function importEditorMapFile(file) {
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error('O ficheiro é demasiado grande (máximo 1 MB).');
      const parsed = JSON.parse(await file.text());
      editorMap = sanitizeEditorMap(parsed);
      editorHistory = []; editorSelectedId = null;
      syncEditorInputs(); renderEditorMap(); refreshEditorSelection();
      setEditorMessage(`Fase importada: ${editorMap.name}. Revê o mapa e testa-o antes de partilhar.`);
    } catch (error) { setEditorMessage(error.message || 'Não foi possível importar o ficheiro.', true); }
  }

  function openPhaseEditor() {
    startScreen.classList.add('hidden'); chamberScreen.classList.add('hidden'); saveScreen.classList.add('hidden');
    pauseScreen.classList.add('hidden'); hud.classList.add('hidden');
    editorScreen.classList.remove('hidden'); isPlaying = false; updateMobileControlsVisibility();
    if (!editorMap) editorMap = makeBlankEditorMap();
    syncEditorInputs(); renderEditorMap(); refreshEditorSelection(); renderEditorSavedList();
  }

  function initializeEditor() {
    editorMap = makeBlankEditorMap();
    editorSavedMaps = readEditorMaps();
    renderEditorSavedList();
    renderEditorMap();

    document.querySelectorAll('.editor-tool').forEach(button => button.addEventListener('click', () => selectEditorTool(button.dataset.tool)));
    editorCanvas.addEventListener('pointerdown', event => {
      event.preventDefault();
      const cell = editorCellAt(event);
      if (cell) placeEditorItem(cell);
    });
    [editorName, editorAuthor, editorObjective].forEach(input => input.addEventListener('input', updateEditorMetaFromInputs));
    document.getElementById('editor-undo').addEventListener('click', undoEditorAction);
    document.getElementById('editor-delete-selected').addEventListener('click', () => {
      if (!editorSelectedId) { setEditorMessage('Seleciona primeiro um objeto no mapa.', true); return; }
      pushEditorHistory();
      if (editorSelectedId === 'spawn') editorMap.spawn = { x: 18, y: 23 };
      else if (editorSelectedId === 'exit') editorMap.exit = { x: 0, y: 7 };
      else editorMap.objects = editorMap.objects.filter(item => item.id !== editorSelectedId);
      editorSelectedId = null; renderEditorMap(); refreshEditorSelection(); setEditorMessage('Objeto removido.');
    });
    document.getElementById('editor-rotate-selected').addEventListener('click', () => {
      const item = editorMap.objects.find(entry => entry.id === editorSelectedId && entry.kind === 'panel');
      if (!item) { setEditorMessage('Seleciona primeiro um painel para portais.', true); return; }
      pushEditorHistory(); item.rotation = ((item.rotation || 0) + 1) % 4;
      refreshEditorSelection(); renderEditorMap(); setEditorMessage(`Painel rodado ${item.rotation * 90} graus.`);
    });
    document.getElementById('editor-clear').addEventListener('click', clearEditorMap);
    document.getElementById('editor-save-local').addEventListener('click', saveEditorMapLocally);
    document.getElementById('editor-load-local').addEventListener('click', loadSelectedEditorMap);
    document.getElementById('editor-delete-local').addEventListener('click', deleteSelectedEditorMap);
    document.getElementById('editor-export').addEventListener('click', downloadEditorMap);
    document.getElementById('editor-share').addEventListener('click', shareEditorMap);
    document.getElementById('editor-import-trigger').addEventListener('click', () => document.getElementById('editor-import-file').click());
    document.getElementById('editor-import-file').addEventListener('change', event => {
      importEditorMapFile(event.target.files && event.target.files[0]); event.target.value = '';
    });
    document.getElementById('editor-test').addEventListener('click', testEditorMap);
    document.getElementById('editor-back').addEventListener('click', () => {
      editorScreen.classList.add('hidden'); startScreen.classList.remove('hidden'); updateMobileControlsVisibility();
    });
  }

  // ------------------------------
  // 12B. CONTROLADORES PARA TELEMÓVEL / TABLET
  // ------------------------------
  function updateMobileControlsVisibility() {
    document.body.classList.toggle('touch-mode', touchDevice);
    if (mobileControls) mobileControls.classList.toggle('hidden', !touchDevice || !isPlaying);
  }

  function resetTouchControls() {
    touchMove.x = 0; touchMove.y = 0;
    touchActions.jump = false; touchActions.run = false;
    mobileLook.pointerId = null;
    if (joystickKnob) joystickKnob.style.transform = 'translate(-50%, -50%)';
    document.querySelectorAll('.mobile-action.pressed').forEach(button => button.classList.remove('pressed'));
  }

  function initializeMobileControls() {
    updateMobileControlsVisibility();
    // Um limite mais baixo de pixel ratio reduz a carga gráfica em telemóveis.
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, touchDevice ? 1.35 : 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    if (mobileJoystick) {
      const radius = 39;
      const updateStick = event => {
        const rect = mobileJoystick.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        let dx = event.clientX - centerX;
        let dy = event.clientY - centerY;
        const length = Math.hypot(dx, dy);
        if (length > radius) { dx = dx / length * radius; dy = dy / length * radius; }
        touchMove.x = dx / radius;
        touchMove.y = dy / radius;
        joystickKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
      };
      mobileJoystick.addEventListener('pointerdown', event => {
        event.preventDefault(); mobileJoystick.setPointerCapture(event.pointerId); mobileJoystick.dataset.pointer = String(event.pointerId); updateStick(event);
      });
      mobileJoystick.addEventListener('pointermove', event => {
        if (mobileJoystick.dataset.pointer === String(event.pointerId)) updateStick(event);
      });
      const releaseStick = event => {
        if (mobileJoystick.dataset.pointer !== String(event.pointerId)) return;
        mobileJoystick.dataset.pointer = ''; touchMove.x = 0; touchMove.y = 0;
        joystickKnob.style.transform = 'translate(-50%, -50%)';
      };
      mobileJoystick.addEventListener('pointerup', releaseStick);
      mobileJoystick.addEventListener('pointercancel', releaseStick);
    }

    document.querySelectorAll('.mobile-action').forEach(button => {
      const action = button.dataset.action;
      button.addEventListener('pointerdown', event => {
        event.preventDefault(); button.setPointerCapture?.(event.pointerId); button.classList.add('pressed');
        if (action === 'jump' || action === 'run') touchActions[action] = true;
        else if (!isPlaying) return;
        else if (action === 'blue') shootPortal('blue');
        else if (action === 'orange') shootPortal('orange');
        else if (action === 'interact') interact();
        else if (action === 'pause') pauseGame();
      });
      const release = () => {
        button.classList.remove('pressed');
        if (action === 'jump' || action === 'run') touchActions[action] = false;
      };
      button.addEventListener('pointerup', release);
      button.addEventListener('pointercancel', release);
      button.addEventListener('lostpointercapture', release);
    });

    renderer.domElement.addEventListener('pointerdown', event => {
      if (!touchDevice || !isPlaying || event.pointerType !== 'touch') return;
      if (event.clientX < window.innerWidth * 0.32) return;
      mobileLook.pointerId = event.pointerId; mobileLook.x = event.clientX; mobileLook.y = event.clientY;
      renderer.domElement.setPointerCapture?.(event.pointerId);
    });
    renderer.domElement.addEventListener('pointermove', event => {
      if (mobileLook.pointerId !== event.pointerId || !isPlaying) return;
      const dx = event.clientX - mobileLook.x;
      const dy = event.clientY - mobileLook.y;
      mobileLook.x = event.clientX; mobileLook.y = event.clientY;
      yaw -= dx * mobileLookSensitivity;
      pitch -= dy * mobileLookSensitivity * 0.88;
      pitch = THREE.MathUtils.clamp(pitch, -1.42, 1.42);
      camera.rotation.set(pitch, yaw, 0, 'YXZ');
    });
    const releaseLook = event => { if (mobileLook.pointerId === event.pointerId) mobileLook.pointerId = null; };
    renderer.domElement.addEventListener('pointerup', releaseLook);
    renderer.domElement.addEventListener('pointercancel', releaseLook);
    window.addEventListener('blur', resetTouchControls);
    window.addEventListener('orientationchange', () => setTimeout(() => {
      touchDevice = Boolean((window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints || 0) > 0);
      updateMobileControlsVisibility();
    }, 180));
  }

  // ------------------------------
  // 13. EVENTOS DO TECLADO E DO RATO
  // ------------------------------
  window.addEventListener('keydown', event => {
    keys[event.code] = true;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    if (event.repeat) return;
    if (event.code === 'KeyE') interact();
    if (event.code === 'KeyV') {
      voiceEnabled = !voiceEnabled;
      if (!voiceEnabled && 'speechSynthesis' in window) window.speechSynthesis.cancel();
      voiceIndicator.textContent = voiceEnabled ? 'VOICE: ON · V' : 'VOICE: OFF · V';
      sayAI(voiceEnabled ? 'voiceOn' : 'voiceOff');
    }
    if (event.code === 'KeyR' && isPlaying) restartCurrentLevel();
    if (event.code === 'Escape' && isPlaying && document.pointerLockElement !== renderer.domElement) pauseGame();
  });

  window.addEventListener('keyup', event => { keys[event.code] = false; });
  window.addEventListener('blur', () => { for (const key of Object.keys(keys)) keys[key] = false; });

  document.addEventListener('pointerlockchange', () => {
    if (document.pointerLockElement === renderer.domElement) {
      pointerWasLocked = true;
      pauseScreen.classList.add('hidden');
      return;
    }
    // Não pausa o primeiro arranque se o navegador bloquear o pointer lock;
    // a pessoa pode clicar novamente no canvas para tentar capturar o rato.
    if (pointerWasLocked && isPlaying && hasStarted && !levelFinished) {
      pointerWasLocked = false;
      pauseScreen.classList.remove('hidden');
      isPlaying = false;
    }
  });

  document.addEventListener('mousemove', event => {
    if (!isPlaying || document.pointerLockElement !== renderer.domElement) return;
    yaw -= event.movementX * 0.00185;
    pitch -= event.movementY * 0.00175;
    pitch = THREE.MathUtils.clamp(pitch, -1.42, 1.42);
    camera.rotation.set(pitch, yaw, 0, 'YXZ');
  });

  renderer.domElement.addEventListener('mousedown', event => {
    if (!isPlaying || touchDevice) return;
    if (document.pointerLockElement !== renderer.domElement) {
      renderer.domElement.requestPointerLock?.();
      return;
    }
    if (event.button === 0) shootPortal('blue');
    if (event.button === 2) shootPortal('orange');
  });
  renderer.domElement.addEventListener('contextmenu', event => event.preventDefault());

  document.getElementById('start-button').addEventListener('click', () => {
    hasStarted = false;
    buildLevel(0);
    startGame();
  });
  document.getElementById('continue-button').addEventListener('click', () => {
    if (saveData.campaignComplete && saveData.auto) {
      startScreen.classList.add('hidden');
      totalTimer.textContent = formatTime(saveData.auto.totalElapsed || 0);
      endingScreen.classList.remove('hidden');
      return;
    }
    if (saveData.auto) {
      loadSnapshot(saveData.auto);
    } else {
      buildLevel(Math.min(LEVELS.length - 1, Math.max(0, unlockedLevel)));
      hasStarted = false;
      startGame();
    }
  });
  document.getElementById('options-menu-button').addEventListener('click', () => {
    menuExtra.classList.remove('hidden');
    menuExtraText.textContent = touchDevice ? `VOICE: ${voiceEnabled ? 'ON' : 'OFF'} · Controlos táteis ativos: joystick para andar, arrastar o lado direito para olhar, BLUE / ORANGE para disparar portais, USE para interagir e JUMP para saltar.` : `VOICE: ${voiceEnabled ? 'ON' : 'OFF'} · V alterna a voz. WASD mover, rato olhar, espaço saltar, E interagir, clique esquerdo/direito disparar portais.`;
  });
  document.getElementById('chambers-menu-button').addEventListener('click', showChapterSelect);
  document.getElementById('saves-menu-button').addEventListener('click', showSaveManager);
  document.getElementById('editor-menu-button').addEventListener('click', openPhaseEditor);
  document.getElementById('chamber-back-button').addEventListener('click', () => { chamberScreen.classList.add('hidden'); startScreen.classList.remove('hidden'); });
  document.getElementById('save-back-button').addEventListener('click', () => {
    saveScreen.classList.add('hidden');
    if (saveManagerReturnToPause) { pauseScreen.classList.remove('hidden'); saveManagerReturnToPause = false; }
    else startScreen.classList.remove('hidden');
  });
  document.getElementById('quit-button').addEventListener('click', () => {
    menuExtra.classList.remove('hidden');
    menuExtraText.textContent = 'O navegador não permite fechar este separador automaticamente. Podes fechar a janela para sair do laboratório.';
  });
  document.getElementById('menu-extra-close').addEventListener('click', () => menuExtra.classList.add('hidden'));
  document.getElementById('resume-button').addEventListener('click', resumeGame);
  document.getElementById('restart-button').addEventListener('click', restartCurrentLevel);
  document.getElementById('quick-save-button').addEventListener('click', () => {
    if (customTestMode) { showToast('SAVE CUSTOM MAP IN THE EDITOR', 1.6); return; }
    const ok = saveAutoCheckpoint();
    showToast(ok === false ? 'SAVE FAILED · STORAGE UNAVAILABLE' : 'QUICK SAVE COMPLETE', 1.5);
  });
  document.getElementById('manage-saves-button').addEventListener('click', () => showSaveManager(true));
  document.getElementById('return-editor-button').addEventListener('click', returnFromCustomTest);
  document.getElementById('next-button').addEventListener('click', goToNextLevel);
  document.getElementById('play-again-button').addEventListener('click', () => {
    if (saveData) { saveData.campaignComplete = false; writeSaveData(); }
    buildLevel(0);
    endingScreen.classList.add('hidden');
    hud.classList.remove('hidden');
    hasStarted = false;
    startGame();
  });

  // ------------------------------
  // 14. CICLO PRINCIPAL DO JOGO
  // ------------------------------
  function animate() {
    requestAnimationFrame(animate);
    const dt = Math.min(clock.getDelta(), 0.05);
    updatePortalDevice(clock.elapsedTime);
    updateLiftDoors(entryLift, dt);
    updateLiftDoors(exitLift, dt);
    updateLiftSequence(dt);
    updateMovingPlatforms(dt);
    for (const pool of toxicPools) {
      pool.phase += dt;
      pool.ripples.forEach((ripple, index) => { ripple.rotation.z += dt * (index % 2 ? -0.18 : 0.14); ripple.material.opacity = 0.18 + (Math.sin(pool.phase * 1.7 + index) + 1) * 0.06; });
      pool.surface.position.y = 0.035 + Math.sin(pool.phase * 1.8) * 0.009;
    }

    // Os anéis dos portais rodam mesmo quando o jogo está no menu.
    for (const portal of [portals.blue, portals.orange]) {
      if (portal) {
        portal.ringA.rotation.z += dt * 0.055;
        portal.ringB.rotation.z -= dt * 0.035;
      }
    }

    if (storyCardTimer > 0) {
      storyCardTimer -= dt;
      if (storyCardTimer <= 0) storyCard.classList.add('hidden');
    }
    if (voiceHideTimer > 0) {
      voiceHideTimer -= dt;
      if (voiceHideTimer <= 0) voiceSubtitle.classList.remove('visible');
    }

    if (isPlaying) {
      elapsedLevel += dt;
      autoSaveTimer += dt;
      if (!customTestMode && autoSaveTimer >= 12) { saveAutoCheckpoint(); autoSaveTimer = 0; }
      timerLabel.textContent = formatTime(elapsedLevel);
      portalCooldown = Math.max(0, portalCooldown - dt);
      updateMovement(dt);
      updateCubes(dt);
      updatePlates();
      checkExit();

      lastHintUpdate += dt;
      if (lastHintUpdate > 0.12) {
        updateInteractionHint();
        lastHintUpdate = 0;
      }
      if (lastToastTimer > 0) {
        lastToastTimer -= dt;
        if (lastToastTimer <= 0) toast.classList.remove('show');
      }
    }

    // Atualizar as duas câmaras virtuais a 30 fps reduz custo sem perder fluidez visual.
    portalViewTimer += dt;
    if (portals.blue && portals.orange && portalViewTimer >= (1 / 30)) {
      updatePortalViews();
      portalViewTimer = 0;
    }
    renderer.render(scene, camera);
  }

  // Redimensiona a imagem 3D quando a janela muda de tamanho.
  window.addEventListener('resize', () => {
    touchDevice = Boolean((window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints || 0) > 0);
    updateMobileControlsVisibility();
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, touchDevice ? 1.35 : 2));
  });

  if ('speechSynthesis' in window) window.speechSynthesis.getVoices();

  // ------------------------------
  // 15. ARRANQUE
  // ------------------------------
  document.getElementById('menu-chamber-count').textContent = `${LEVELS.length} TEST CHAMBERS · PHASE EDITOR · LOCAL SAVES`;
  initializeEditor();
  initializeMobileControls();
  createPortalDevice();
  buildLevel(0);
  // Ângulo de menu cinematográfico; ao iniciar, buildLevel repõe a posição jogável.
  camera.position.set(8.8, 6.9, 10.5);
  yaw = 0.72;
  pitch = -0.30;
  camera.rotation.set(pitch, yaw, 0, 'YXZ');
  animate();
  loadingNote.textContent = 'MOTOR 3D PRONTO';
  setTimeout(() => { loadingNote.style.opacity = '0'; }, 2400);
})();
